import pysam as ps
import numpy as np
import collections
import matplotlib.pyplot as plt
from numpy.core.defchararray import array, center
import pysam as ps
import numpy as np
from collections import defaultdict
from scipy.ndimage.measurements import label
from sklearn.cluster import KMeans
import sys
from scipy.signal import savgol_filter
import math
from subprocess import call
import os.path
from utils import Gene, TSS, Point

win = 200

dic = {
    'TSSs_l':'./data/gene/low_expressed.bed',
    'location':'./data/gene/GRCh37.gene.bed',
    'bam':'./data/051.bam',
    'TSS_HK':'./data/gene/HK.bed',
    'TSS_silent':'./data/gene/silent_gene_TSS.bed'
    }

bamfile = ps.AlignmentFile(dic['bam'],'rb')

win_fraction = []

plist = []

for r in bamfile:
    if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse and r.mapq > 30:
        ss = r.reference_start
        ee = abs(r.isize)
        plist.append(Point(ss, ee))
    plist = sorted(plist, key= lambda a: a.x)

print(len(plist))

k = plist[0].x
i = 0
while True:
    ss = k
    ee = k + win
    if ee > plist[-1].x:
        break
    k = k + win/2
    _set = [p for p in plist if ss <= p.x <= ee]
    s1 = [p for p in _set if p.y <= 140]
    s2 = [p for p in _set if p.y > 140]
    if len(s1) + len(s2) != 0:
        fraction = float(len(s1)/(len(s1)+len(s2)))
        win_fraction.append(fraction)
    i += len(s1) + len(s2)

plt.plot([i for i in range(len(win_fraction))], [i  for i in win_fraction], color = 'b')
plt.show()

