from collections import defaultdict

from numpy.core.fromnumeric import sort
dic = {
    'gene':'./data/gene/GRCh37.gene.bed',
    'silent':'./data/gene/silent_gene.bed',
    # 'out':'./data/gene/silent_gene_location.bed',
    'out':'./data/gene/HK_gene_location.bed',
    'HK':'./data/gene/HK.bed',
}
class Gene:
    def __init__(self, chrom, start, end, strand, name):
        self.chrom = chrom
        self.start = int(start)
        self.end = int(end)
        self.strand = strand
        self.name = name
    def __str__(self):
        return "{}\t{}\t{}\t{}\t{}\n".format(self.chrom, self.start, self.end, self.strand, self.name)
gfile = open(dic['gene'],'r')
gene_dic = {}
for line in gfile:
    ll = line.strip().split('\t')
    if ll[0] in ['MT','NULL']:
        continue
    gene_dic[ll[4]] = Gene(ll[0], ll[1], ll[2], ll[3], ll[4])
# sfile = open(dic['silent'],'r')
# genelist = []
# for gene in sfile:
#     gene = gene.strip()
#     if gene not in gene_dic:
#         continue
#     genelist.append(gene_dic[gene])
# genelist = sorted(genelist, key= lambda x: (x.chrom, x.start, x.end))
# outfile = open(dic['out'],'w')
# for gene in genelist:
#     outfile.write(str(gene))
sfile = open(dic['HK'],'r')
genelist = []
for gene in sfile:
    gene = gene.strip().split('\t')[-1]
    if gene not in gene_dic:
        continue
    genelist.append(gene_dic[gene])
genelist = sorted(genelist, key= lambda x: (x.chrom, x.start, x.end))
outfile = open(dic['out'],'w')
for gene in genelist:
    outfile.write(str(gene))


