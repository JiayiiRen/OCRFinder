import pysam as ps
import numpy as np
import collections
import matplotlib.pyplot as plt
from numpy.core.defchararray import array, center
import pysam as ps
import numpy as np
from collections import defaultdict
from scipy.ndimage.measurements import label
from sklearn.cluster import KMeans
import sys
from scipy.signal import savgol_filter
import math
from subprocess import call
import os.path
from utils import Gene, TSS, Point
from scipy.fftpack import fft
# from wps_fraction_single import TSSs_l

dic = {
    'TSSs_l':'./data/gene/low_expressed.bed',
    'location':'./data/gene/GRCh37.gene.bed',
    'bam':'./data/051.bam',
    'TSS_HK':'./data/gene/HK.bed',
    'TSS_silent':'./data/gene/silent_gene_TSS.bed'
    }

chr_to_id = {
    'chr1':'1','chr2':'2','chr3':'3','chr4':'4','chr5':'5','chr6':'6','chr7':'7','chr8':'8','chr9':'9','chr10':'10','chr11':'11','chr12':'12','chr13':'13','chr14':'14','chr15':'15','chr16':'16','chr17':'17','chr18':'18','chr19':'19','chr20':'20','chr21':'21','chr22':'22','chrX':'X','chrY':'Y'
}


bamfile = ps.AlignmentFile(dic['bam'],'rb')

TSS_silent = []
with open(dic['TSS_silent'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == '1':
            TSS_silent.append(TSS(ll[0], int(ll[1])+int(1000)))

TSS_HK = []
with open(dic['TSS_HK'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == '1':
            TSS_HK.append(TSS(ll[0], int(ll[1])+int(1000)))

def getMMM(tmpArray):
    tmpArray = np.array(tmpArray)
    return np.min(tmpArray), np.median(tmpArray), np.max(tmpArray)

def AdjustWPS(wpsList):
    n = len(wpsList)
    # lenth = n - win - 1
    subarray = wpsList[0: n]
    tmpLength = len(subarray)
    # medianA = np.zeros(tmpLength)
    # chaA = np.zeros(tmpLength)
    medianA = [0] * tmpLength
    chaA = [0] * tmpLength
    adjustWin = 1000
    mid = 500
    start = 0
    end = adjustWin + 1
    while end <= tmpLength:
        tmpArray = subarray[start: end]
        minn, median, maxn = getMMM(tmpArray)
        tmploc = int((start + end + 1) / 2)
        medianA[tmploc] = median
        chaA[tmploc] = maxn - minn + 1
        start += 1
        end += 1
    x = 0
    while x < tmpLength:
        loc = x
        if loc < 501:
            loc = 501
        if loc >= tmpLength - 501:
            loc = tmpLength - 501
        # print(chaA)
        subarray[x] = (subarray[x] - medianA[loc]) / chaA[loc]
        x += 1
    return np.array(subarray)

TSSs_l = TSS_HK
count = 0
for tss in TSSs_l:
    win = 120
    chrom = tss.chrom
    start = tss.pos - 1000
    end = tss.pos + 1000
    length = end-start
    wps_list_total = np.zeros(length, dtype=float)
    wps_list_part = np.zeros(length, dtype=float)
    for r in bamfile.fetch(chrom, start, end):
        if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse and r.mapq > 30:
            if r.isize < win or r.isize > 180:
                continue
            ss = r.reference_start - start
            ee = ss + abs(r.isize)

            # wps_total
            region1 = int(max(0, ss + win/2))
            region2 = int(min(ee - win/2, end-start))
            i = region1
            while i < region2:
                wps_list_total[i] += 1
                i = i+1
            # wps_part
            region1 = int(max(0, ss - win/2))
            region2 = int(min(end-start, ss + win/2))
            i = region1
            while i < region2:
                wps_list_part[i] += 1
                i = i + 1
            # wps_part
            region1 = int(max(ee - win/2, 0))
            region2 = int(min(ee + win/2, end-start))
            i = region1
            while i < region2:
                wps_list_part[i] += 1
                i = i+1
    for i in range(len(wps_list_part)):
        if wps_list_part[i] == 0:
            k = i
            while k > 0 and wps_list_part[k] == 0:
                k = k - 1
            p = i
            while p < len(wps_list_part) - 1 and wps_list_part[p] == 0:
                p = p + 1
            wps_list_part[i] = (wps_list_part[k] + wps_list_part[p]) / 2
        
        if wps_list_total[i] == 0:
            k = i
            while k > 0 and wps_list_total[k] == 0:
                k = k - 1
            p = i
            while p < len(wps_list_part) - 1 and wps_list_total[p] == 0:
                p = p + 1
            wps_list_total[i] = (wps_list_total[k] + wps_list_total[p]) / 2
    wpslist = [wps_list_total[i] - wps_list_part[i] for i in range(len(wps_list_part))]
    # wpslist = AdjustWPS(wpslist)
    wpslist = savgol_filter(wpslist, 51, 1)
    plt.plot([x for x in range(len(wpslist))], wpslist)
    plt.show()
    k = 0
    T = 150
    while k < end - start:
        ss = k
        ee = k + 3*T
        k = k + T
        ww = wpslist[ss:ee]
        fft_ww = fft(ww)
        x = [i for i in range(len(ww))]
        plt.plot(x[:50],fft_ww[:50])
        plt.title(str(ss)+'-'+str(ee))
        plt.show()


    # break
    # count += 1
    # plt.subplot(610+count)
    # plt.plot([i for i in range(len(wpslist))],wpslist, color='b')
    # plt.title(str(start)+'-'+str(end))
    if count > 5:
        break
# plt.show()