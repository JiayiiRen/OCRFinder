from tensorflow.keras.datasets import cifar10
import numpy as np
from tensorflow.keras.utils import to_categorical
import random
from collections import defaultdict
from sklearn.utils import shuffle
import copy
import random
import math
from matplotlib import pyplot as plt
seed = 7
np.random.seed(seed)
# def load_mnist(path):
#     with np.load(path, allow_pickle=True) as f:
#         x_train, y_train = f['x_train'], f['y_train']
#         x_test, y_test = f['x_test'], f['y_test']

#     return (x_train, y_train), (x_test, y_test)
# (x_train, y_train), (x_test, y_test) = load_mnist('../data/mnist.npz')

(x_train, y_train), (x_test, y_test) = cifar10.load_data()
x_train, y_train = shuffle(x_train,y_train, random_state=3927)
x_train = x_train.astype('float32')/255.0
x_test = x_test.astype('float32')/255.0

# num_pixels = x_train.shape[1]*x_train.shape[2]
# x_train = x_train.reshape(x_train.shape[0],num_pixels).astype('float32')
# x_test = x_test.reshape(x_test.shape[0],num_pixels).astype('float32')
# x_train = x_train/255.0
# x_test = x_test/255.0

noise_fraction = 0.4

y_train_ori = copy.copy(y_train)

y_id = np.array([i for i in range(len(y_train))])
noise_ids = np.random.choice(y_id, int(len(y_train)*noise_fraction), replace=False)
for id in noise_ids:
    yy = y_train[id]
    ra = np.random.randint(1,10)
    yy_n = (ra+yy)%10

    y_train[id] = yy_n

clean_ids = []
for id in range(len(x_train)):
    if id in noise_ids:
        continue
    clean_ids.append(id)
# y_train, y_train_ori, y_test = to_categorical(y_train), to_categorical(y_train_ori), to_categorical(y_test)

'''create_model'''
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, Callback
from sklearn.model_selection import KFold
from tensorflow.keras import backend as K
# def create_model():
#     model = keras.models.Sequential()
#     model.add(layers.Dense(num_pixels, activation='relu', input_dim=num_pixels))
#     model.add(layers.Dense(128, activation='relu'))
#     # model.add(layers.Dense(100, activation='relu'))
#     model.add(layers.Dense(10, activation='softmax'))
#     # adam = keras.optimizers.Adam(lr=1e-4)
#     # model.compile(optimizer=adam, loss='binary_crossentropy', metrics=['accuracy'])
#     return model
from tensorflow.keras.layers import Conv2D,MaxPooling2D,Dense,Dropout,Flatten
def create_model():
    model = keras.models.Sequential()
    model.add(Conv2D(filters=32,
                    kernel_size=(3,3),
                    input_shape=(32,32,3),
                    activation='relu',
                    padding='same'))
    # model.add(Dropout(0.25))
    model.add(MaxPooling2D(pool_size=(2,2)))
    model.add(Conv2D(filters=64, kernel_size=(3, 3),
                    activation='relu', padding='same'))
    # model.add(Dropout(0.25))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Conv2D(filters=128, kernel_size=(3, 3),
                    activation='relu', padding='same'))
    # model.add(Dropout(0.25))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Flatten())
    # model.add(Dropout(rate=0.50))　　　
    model.add(Dense(512, activation='relu'))
    # model.add(Dropout(rate=0.50))
    model.add(Dense(10, activation='softmax'))
    return model

def CE_MAE(y_true, y_pred):
    ce = K.categorical_crossentropy(y_true, y_pred)
    mae = K.mean(K.abs(y_true-y_pred), axis=-1)
    alpha = (10000/1000)**0.5
    # alpha = 1
    return ce + alpha*mae
base_model = create_model()
adam = keras.optimizers.Adam(lr=1e-4)
epochs = 100
batchsize = 128
# base_model.compile(optimizer=adam, loss=keras.losses.CategoricalCrossentropy(), metrics=['accuracy'])
# base_model.compile(optimizer=adam, loss=keras.losses.MeanAbsoluteError() , metrics=['accuracy'])
base_model.compile(optimizer=adam, loss=CE_MAE , metrics=['accuracy'])
y_id = np.array([i for i in range(len(y_train))])
ids = np.random.choice(y_id, int(len(y_id)*0.2), replace=False)
print("sample amount:", len(ids))
x_train, y_train = x_train[ids], y_train[ids]
base_his = base_model.fit(x_train, to_categorical(y_train), epochs=epochs, batch_size=batchsize, verbose=2, validation_data=(x_test,to_categorical(y_test)))
import pickle
with open('ce_mae_weights/mnist_ce_mae_10.txt','wb') as f:
    pickle.dump(base_his.history, f)