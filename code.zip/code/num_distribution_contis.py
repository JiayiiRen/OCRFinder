import pysam as ps
import numpy as np
import collections
import matplotlib.pyplot as plt
from numpy.core.defchararray import array, center
import pysam as ps
import numpy as np
from collections import defaultdict
from scipy.ndimage.measurements import label
from sklearn.cluster import KMeans
import sys
from scipy.signal import savgol_filter
import math
from subprocess import call
import os.path
from utils import Gene, TSS, Point
from tqdm import tqdm

dic = {
    'TSSs_l':'./data/gene/low_expressed.bed',
    'location':'./data/gene/GRCh37.gene.bed',
    'bam':'./data/051.bam',
    'TSS_HK':'./data/gene/HK.bed',
    'TSS_silent':'./data/gene/silent_gene_TSS.bed',
    'Lung':'./excel/Lung.bed',
    'Tcell':'./excel/Tcell.bed',
    'Liver':'./excel/Liver.bed'
    }

chr_to_id = {
    'chr1':'1','chr2':'2','chr3':'3','chr4':'4','chr5':'5','chr6':'6','chr7':'7','chr8':'8','chr9':'9','chr10':'10','chr11':'11','chr12':'12','chr13':'13','chr14':'14','chr15':'15','chr16':'16','chr17':'17','chr18':'18','chr19':'19','chr20':'20','chr21':'21','chr22':'22','chrX':'X','chrY':'Y'
}

bamfile = ps.AlignmentFile(dic['bam'],'rb')

up = 5000
down = 5000

length_cutoff = 150

count = 0
TSS_silent = []
with open(dic['TSS_silent'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] in ['1']:
            TSS_silent.append(TSS(ll[0], int(ll[1])+int(1000)))
# print(len(TSS_silent))
TSS_HK = []
with open(dic['TSS_HK'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] in ['1']:
            TSS_HK.append(TSS(ll[0], int(ll[1])+int(1000)))

# TSS_HK = TSS_HK[:len(TSS_silent)]
TSS_tissue = []
with open(dic['Tcell'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        # if ll[0] in ['chr1']:
        #     TSSs_l.append(TSS(chr_to_id[ll[0]],int(ll[1])))
        if ll[0] in ['1']:
            TSS_tissue.append(TSS(ll[0],int(ll[1])))
TSS_l = []
with open(dic['TSSs_l'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == 'chr1':
            TSS_l.append(TSS(chr_to_id[ll[0]],int(ll[1])))

TSSs_l = TSS_tissue
print(len(TSSs_l))

long_array = np.zeros(up+down, dtype=float)
short_array = np.zeros(up+down, dtype=float)
count_long_array = np.zeros(up+down, dtype=float)
count_short_array = np.zeros(up+down, dtype=float)
for i in tqdm(range(len(TSSs_l))):
    tss = TSSs_l[i]
    chrom = tss.chrom
    start = tss.pos - up
    end = tss.pos + down
    # long_array = np.zeros(up+down, dtype=float)
    # short_array = np.zeros(up+down, dtype=float)
    count_long = defaultdict(bool)
    count_short = defaultdict(bool)    
    plist = []
    for r in bamfile.fetch(chrom, start, end):
         if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse and r.mapq > 30:
            # if abs(r.isize) > 200 or abs(r.isize) < 100:
            #     continue
            ss = max(r.reference_start - start, 0)
            ee = min(end - start, ss + abs(r.isize))
            if abs(r.isize) <= length_cutoff:
                for i in range(ss, ee):
                    short_array[i] += 1
                    if not count_short[i]:
                        count_short[i] = True
            else:
                for i in range(ss,ee):
                    long_array[i] += 1
                    if not count_long[i]:
                        count_long[i] = True
    for i in range(len(short_array)):
        if count_long[i]:
            count_long_array[i] += 1
        if count_short[i]:
            count_short_array[i] += 1
for i in range(len(short_array)):
    short_array[i] = short_array[i] / count_short_array[i]
    long_array[i] = long_array[i] / count_long_array[i]

# cov_long = (np.mean(long_array[-1000:]) + np.mean(long_array[:1000])) / 2
# cov_short = (np.mean(short_array[-1000:]) + np.mean(short_array[-1000:])) / 2
total_array = long_array + short_array
cov = np.mean(list(total_array[:1000])+list(total_array[-1000:]))
# print(cov_long,cov_short)
num_long = np.mean(long_array[5000-150:5000+150]) / cov
num_short = np.mean(short_array[5000-150:5000+150]) / cov
print(num_long,num_short)
fraction_array = [long_array[i] / (long_array[i]+short_array[i]) for i in range(len(long_array))]

# plt.plot([i for i in range(len(short_array[4000:6000]))], [nn/cov for nn in short_array[4000:6000]], color = 'b', label= 's')
# plt.plot([i for i in range(len(long_array[4000:6000]))], [nn/cov for nn in long_array[4000:6000]], color = 'r', label = 'l')
# plt.plot([i for i in range(len(long_array[4000:6000]))], fraction_array[4000:6000], color = 'g', label = 'l/(l+s)')
plt.plot([i for i in range(len(short_array))], [nn/cov for nn in short_array], color = 'b', label= 's')
plt.plot([i for i in range(len(long_array))], [nn/cov for nn in long_array], color = 'r', label = 'l')
plt.plot([i for i in range(len(long_array))], fraction_array, color = 'g', label = 'l/(l+s)')
plt.legend(loc=4)
plt.title('cutoff =150bp')
plt.show()            
