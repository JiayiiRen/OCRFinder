import pysam as ps
import numpy as np
import collections
import matplotlib.pyplot as plt
from numpy.core.defchararray import array, center
import pysam as ps
import numpy as np
from collections import defaultdict
from scipy.ndimage.measurements import label
from sklearn.cluster import KMeans
import sys
from scipy.signal import savgol_filter
import math
from subprocess import call
import os.path
from utils import Gene, TSS, Point

dic = {
    'TSSs_l':'./data/gene/low_expressed.bed',
    'location':'./data/gene/GRCh37.gene.bed',
    'bam':'./data/051.bam',
    'TSS_HK':'./data/gene/HK.bed',
    'TSS_silent':'./data/gene/silent_gene_TSS.bed'
    }

chr_to_id = {
    'chr1':'1','chr2':'2','chr3':'3','chr4':'4','chr5':'5','chr6':'6','chr7':'7','chr8':'8','chr9':'9','chr10':'10','chr11':'11','chr12':'12','chr13':'13','chr14':'14','chr15':'15','chr16':'16','chr17':'17','chr18':'18','chr19':'19','chr20':'20','chr21':'21','chr22':'22','chrX':'X','chrY':'Y'
}

bamfile = ps.AlignmentFile(dic['bam'],'rb')

up = 1000
down = 1000
count = 0
TSS_silent = []
with open(dic['TSS_silent'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == '1':
            TSS_silent.append(TSS(ll[0], int(ll[1])+int(1000)))

TSS_HK = []
with open(dic['TSS_HK'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == '1':
            TSS_HK.append(TSS(ll[0], int(ll[1])+int(1000)))



TSSs_l = TSS_HK
for tss in TSSs_l:
    chrom = tss.chrom
    start = tss.pos - up
    end = tss.pos + down
    long_array = np.zeros(up+down, dtype=float)
    short_array = np.zeros(up+down, dtype=float)    
    plist = []
    for r in bamfile.fetch(chrom, start, end):
         if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse and r.mapq > 30:
            if abs(r.isize) > 180 or abs(r.isize) < 120:
                continue
            ss = max(r.reference_start - start, 0)
            ee = min(end - start, ss + abs(r.isize))
            if abs(r.isize) <= 140:
                for i in range(ss, ee):
                    short_array[i] += 1
            else:
                for i in range(ss,ee):
                    # print(ss,ee,len(long_array),i)
                    long_array[i] += 1
    fraction_array = np.zeros(up+down, dtype=float)
    for i in range(len(long_array)):
        if short_array[i] == 0:
            u = i
            while u > 0 and short_array[u] == 0:
                u = u - 1
            d = i
            while d < len(long_array) - 1 and short_array[d] == 0:
                d = d + 1
            short_array[i] = (short_array[u] + short_array[d]) / 2
        if long_array[i] == 0:
            u = i
            while u > 0 and long_array[u] == 0:
                u = u - 1
            d = i
            while d < len(long_array) - 1 and long_array[d] == 0:
                d = d + 1
            long_array[i] = (long_array[u] + long_array[d]) / 2
        fraction_array[i] = float(short_array[i] / (short_array[i] + long_array[i]))
        fraction_array = savgol_filter(fraction_array,3,1)
    count += 1
    plt.subplot(610+count)
    plt.plot([i for i in range(len(fraction_array))],fraction_array, color = 'r')
    
    
    if count > 5:
        break
plt.show()            
