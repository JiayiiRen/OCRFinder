import pysam as ps
import numpy as np
import collections
import matplotlib.pyplot as plt
from numpy.core.defchararray import array, center
import pysam as ps
import numpy as np
from collections import defaultdict
from scipy.ndimage.measurements import label
from sklearn.cluster import KMeans
import sys
from scipy.signal import savgol_filter
import math
from subprocess import call
import os.path
from utils import Gene, TSS, Point

dic = {
    'TSSs_l':'./data/gene/low_expressed.bed',
    'location':'./data/gene/GRCh37.gene.bed',
    'bam':'./data/035.bam',
    'TSS_HK':'./data/gene/HK.bed',
    'TSS_silent':'./data/gene/silent_gene_TSS.bed'
    }

chr_to_id = {
    'chr1':'1','chr2':'2','chr3':'3','chr4':'4','chr5':'5','chr6':'6','chr7':'7','chr8':'8','chr9':'9','chr10':'10','chr11':'11','chr12':'12','chr13':'13','chr14':'14','chr15':'15','chr16':'16','chr17':'17','chr18':'18','chr19':'19','chr20':'20','chr21':'21','chr22':'22','chrX':'X','chrY':'Y'
}

bamfile = ps.AlignmentFile(dic['bam'],'rb')

length_dic = {}
length_key = []
count = 0
for r in bamfile:
    if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse and r.mapq > 30:
        ll = abs(r.isize)
        # print(ll)
        if ll > 600:
            continue
        if ll not in length_dic:
            length_dic[ll] = 1
            length_key.append(ll)
            count += 1
        else:
            length_dic[ll] += 1
            count += 1
length_key = sorted(length_key)
# height = []
# for key in length_key:
#     height.append(float(length_dic[key]/count))
# plt.bar(length_key, height)
# plt.show()

x = []
y = []
win = 10
ss = length_key[0]
while True:
    ee = ss + win
    cc = 0
    for i in range(ss, ee):
        if i in length_key:
            cc += length_dic[i]
    x.append(ss)
    y.append(cc)
    ss += win
    if ss > length_key[-1]:
        break
plt.bar(x, y)
plt.show()
        