import pandas as pd
from utils import TSS
import utils
from collections import defaultdict
from subprocess import call
dic = {'excel':'./excel/excel.xlsx',
        'out':'./excel/'
    }

df = pd.read_excel(dic['excel'], sheet_name='Tissue-specific')
data = df.head()
print(data)

chr_to_id = {
    'chr1':'1','chr2':'2','chr3':'3','chr4':'4','chr5':'5','chr6':'6','chr7':'7','chr8':'8','chr9':'9','chr10':'10','chr11':'11','chr12':'12','chr13':'13','chr14':'14','chr15':'15','chr16':'16','chr17':'17','chr18':'18','chr19':'19','chr20':'20','chr21':'21','chr22':'22','chrX':'X','chrY':'Y'
}

tissues = defaultdict(list)

for index, row in df.iterrows():
    tissues[row['Tissue-type']].append(TSS(chr_to_id[row['Chr']], int(row['Start'])+int(1000)))

for ts in tissues.keys():
    with open(dic['out']+str(ts)+'.bed','w') as f:
        for tss in tissues[ts]:
            f.write(str(tss)+'\n')
