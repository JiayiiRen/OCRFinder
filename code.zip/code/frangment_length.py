import collections
import matplotlib.pyplot as plt
from numpy.core.defchararray import array
import pysam as ps
import numpy as np
from collections import defaultdict
from scipy.ndimage.measurements import label
from sklearn.cluster import KMeans
import sys
from scipy.signal import savgol_filter
import math

dic = {
    'bam':'/home/jiay/Desktop/OCR-1/data/051.bam',
    # 'bed':'/home/jiay/Desktop/OCRDetector-master/result/HK.all.txt.bed'
    'bed':'./data/gene/silent_gene_TSS.bed'
}

bamfile = ps.AlignmentFile(dic['bam'],'rb')
bedfile = open(dic['bed'],'r')

seglist = []
for line in bedfile:
    seg = line.strip().split('\t')
    chrom = str(seg[0])
    start = int(seg[1])
    end = int(seg[2])
    seglist.append([chrom, start, end])

count = 0

# '''
#coverage samtools depth
depthfile = open('/home/jiay/Desktop/OCR-1/data/h1.bed')
controlfile = open('/home/jiay/Desktop/OCR-1/data/h1_1.bed')
conlist = []
for line in controlfile:
    conlist.append(int(line.strip().split()[2]))
mm = np.mean(conlist)
mm = 1
xd = []
yd = []
mi = 999
ma = -1
for line in depthfile:
    ll = line.strip().split('\t')
    xd.append(int(ll[1]))
    yd.append(float(int(ll[2]) / mm))
    if mi < float(int(ll[2])/mm):
        mi = float(int(ll[2])/mm)
    if ma > float(int(ll[2])/mm):
        ma = float(int(ll[2])/mm)

depthfiles = open('/home/jiay/Desktop/OCR-1/data/g1.bed')
controlfiles = open('/home/jiay/Desktop/OCR-1/data/g1_1.bed')
conlists = []
for line in controlfiles:
    conlists.append(int(line.strip().split()[2]))
mms = np.mean(conlists)
mms = 1
xds = []
yds = []

for line in depthfiles:
    ll = line.strip().split('\t')
    # xds.append(int(ll[1]))
    yds.append(float(int(ll[2]) / mms))
    if mi < float(int(ll[2])/mms):
        mi = float(int(ll[2])/mms)
    if ma > float(int(ll[2])/mms):
        ma = float(int(ll[2])/mms)

# yds = [(yy-mi)/(ma-mi) for yy in yds]
xss = [i for i in range(len(yds))]
print(len(yds),len(yd))
# yd = [(yy-mi)/(ma-mi) for yy in yd]
yd = savgol_filter(yd,51,1)
yds = savgol_filter(yds,51,1)
plt.plot(xss, yd, color = 'r')
plt.plot(xss,yds, color = 'b')
plt.show()

sys.exit()



# '''



'''
# coverage
for seg in seglist:
    count += 1
    chrom = seg[0]
    start = seg[1]
    end = seg[2]
    covlist = [0] * (end - start)
    _max = -1
    _min = 999
    for r in bamfile.fetch(chrom, start, end):
        if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse and r.mapq > 30:
            ss = r.reference_start - start
            ee = abs(r.isize)
            for i in range(max(0,ss), min(ss + ee, len(covlist))):
                covlist[i] += 1
                if covlist[i] < _min:
                    _min = covlist[i]
                if covlist[i] > _max:
                    _max = covlist[i]
    norm_covlist = [(cov - _min) / (_max - _min) for cov in covlist]
    covlist = savgol_filter(norm_covlist,51,1)
    x = [i+start for i in range(len(covlist))]
    plt.plot(x, covlist)
    # plt.show()
    # plt.savefig('/home/jiay/Desktop/OCR-1/016/' + str(start) + '.png', dpi=1200, format='png')
    # plt.clf()
    plt.show()
    if count > 5:
        break
'''
'''
# length
for seg in seglist:
    count += 1
    chrom = seg[0]
    start = seg[1]
    end = seg[2]
    x = []
    y = []
    for r in bamfile.fetch(chrom, start, end):
        if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse and r.mapq > 30:
            ss = r.reference_start - start
            ee = abs(r.isize)
            x.append(ss)
            y.append(ee)
    plt.scatter(x,y)
    plt.show()
    if count > 5:
        break
'''
'''
# WPS chen
for seg in seglist:
    count += 1
    chrom = seg[0]
    start = seg[1]
    end = seg[2]
    win = 120
    bed1 = start - win
    bed2 = end + win
    length = bed2 - bed1 + 1
    array = np.zeros(length, dtype=np.int)
    depth = np.zeros(length, dtype=np.int)
    depth2 = np.zeros(length, dtype=np.int)

    for r in bamfile.fetch(chrom, bed1, bed2):
        if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse and r.mapq > 30:
            if r.isize >= 35 and r.isize <= 80:
                start = r.reference_start - bed1
                end = r.reference_start + r.isize - bed1
                # depth + 1
                dstart = start
                dend = end
                if dstart < 0:
                    dstart = 0
                if dend > length:
                    dend = length
                d = dstart
                while d < dend:
                    depth2[d] += 1
                    d += 1

            if r.isize < win or r.isize > 180:
                continue
            start = r.reference_start - bed1
            end = r.reference_start + r.isize - bed1
            # depth + 1
            dstart = start
            dend = end
            if dstart < 0:
                dstart = 0
            if dend >= length:
                dend = length
            d = dstart
            while d < dend:
                depth[d] += 1
                d += 1

            # [$start+W/2,$end-W/2] WPS+1
            region1 = start + int(win / 2)
            region2 = end - int(win / 2)
            if region1 < 0:
                region1 = 0
            if region2 > length:
                region2 = length
            i = region1
            while i < region2:
                array[i] += 1
                i += 1
            # [$start-w/2,$start-1+w/2] WPS-1
            region1 = start - int(win / 2)
            region2 = start + int(win / 2) + 1
            if region1 < 0:
                region1 = 0
            if region2 > length:
                region2 = length
            i = region1
            while i < region2:
                array[i] -= 1
                i += 1
            # [end-w/2+1,$end+w/2] WPS-1
            region1 = end - int(win / 2) + 1
            region2 = end + int(win / 2)
            if region1 < 0:
                region1 = 0
            if region2 > length:
                region2 = length
            i = region1
            while i < region2:
                array[i] -= 1
                i += 1
    # adjustWPS = AdjustWPS(array)
    lenth1 = len(array) - win - 1
    bed1 += win
    bed2 -= win
    array = np.array(array[win: lenth1], dtype=np.float)
    depth = depth[win: lenth1]
    depth2 = depth2[win: lenth1]
    wps = savgol_filter(array,51,1)
    x = [i for i in range(len(wps))]
    plt.plot(x,wps)
    plt.show()

'''



class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

def bayes(s1, s2):
    p1 = len(s1) / len(s1) + len(s2)
    p2 = len(s2) / len(s1) + len(s2)



def cluster(plist):
    y1 = plist[0].y
    y2 = plist[1].y
    s1 = [plist[0]]
    s2 = [plist[1]]
    j = 0
    while j < 1000:
        for p in plist:
            if p in s1 or p in s2:
                continue
            if abs(p.y - y1) < abs(p.y - y2):
                s1.append(p)
            else:
                s2.append(p)
        y1 = np.mean([p.y for p in s1])
        y2 = np.mean([p.y for p in s2])
        j = j + 1
        if j < 1000:
            s1 = []
            s2 = []
    # if len(s1) == 0 or len(s2) == 0:
    #     print([p.x for p in plist])
    #     print([p.y for p in plist])
    #     sys.exit()
    if y1 < y2:
        return s1,s2
    return s2,s1

'''
# log shang bayes
for seg in seglist:
    count += 1
    chrom = seg[0]
    start = seg[1]
    end = seg[2]
    win = 200
    plist = []
    for r in bamfile.fetch(chrom, start, end):
        if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse and r.mapq > 30:
            ss = r.reference_start
            ee = abs(r.isize)
            plist.append(Point(ss, ee))
    plist = sorted(plist, key= lambda a: a.x)
    # print(len(plist))
    k = start
    num_win = []
    while k < end:
        # print(i)
        ss = k
        ee = k + win
        k = k + win / 2
        _set = [p for p in plist if ss <= p.x <= ee] # ss <= p.x <= ee and p.x + p.y <= ee
        if len(_set) == 0:
            continue
        
        # y = [p.y for p in _set]
        # mu = np.mean(y)
        # sigma = np.std(y, ddof=1)
        # # print(mu,sigma)
        # _set0 = [p for p in _set if mu-2*sigma <= p.y <= mu+2*sigma]
        # if len(_set0) == 0:
        #     continue
        # s1, s2 = cluster(_set0)
        # plt.scatter([p.x for p in s1],[p.y for p in s1],color = 'b')
        # plt.scatter([p.x for p in s2],[p.y for p in s2],color = 'g')
        # plt.show()
        s1 = [p for p in _set if p.y <= 140]
        s2 = [p for p in _set if p.y > 140]
        # plt.scatter([p.x for p in s1],[p.y for p in s1], color = 'b')
        # plt.scatter([p.x for p in s2], [p.y for p in s2], color = 'g')
        
        num_win.append([len(s1),len(s2),ss])
    # print(num_win)
        # plt.show()
        # plt.clf()
    # plt.show()
    vlist = []
    v1list = []
    v2list = []
    vx = []
    for i in range(1,len(num_win)-1):
        vx.append(num_win[i][2])
        p1 = float(num_win[i][0] / (num_win[i][1] + num_win[i][0]))
        mu1 = np.mean([num_win[i-1][0],num_win[i][0],num_win[i+1][0]])
        sigma1 = np.std([num_win[i-1][0],num_win[i][0],num_win[i+1][0]],ddof=1)
        if sigma1 == 0:
            sigma1 = 0.001
        mu2 = np.mean([num_win[i-1][1],num_win[i][1],num_win[i+1][1]])
        sigma2 = np.std([num_win[i-1][1],num_win[i][1],num_win[i+1][1]],ddof=1)
        if sigma2 == 0:
            sigma2 = 0.001
        v1 = (p1 * math.exp(-((num_win[i][0] - mu1)/(2*sigma1)) ** 2) / sigma1) 
        v2 = ((1 - p1) * math.exp(-((num_win[i][1] - mu2) / (2 * sigma2)) ** 2) / sigma2)
        v1list.append(v1)
        v2list.append(v2)
        if v2 != 0:
            vlist.append(v1/v2)
        else:
            vlist.append(0)
    # vx = [i for i in range(len(vlist))]
    plt.plot(vx,vlist,color = 'b',label='v1/v2')
    # plt.plot(vx,[num_win[i][0] for i in range(1, len(num_win) - 1 )], color = 'g')
    # plt.plot(vx, [num_win[i][1] for i in range(1, len(num_win) - 1)], color = 'r')
    plt.plot(vx, v1list, label='v1',color = 'g')
    plt.plot(vx, v2list, label='v2', color = 'r')
    plt.legend(loc='upper left')
    plt.show()

    if count > 5:
        break
'''

'''
# WPS - win
for seg in seglist:
    count += 1
    chrom = seg[0]
    start = seg[1]
    end = seg[2]
    win = 10
    k = start
    wpslist = []
    totallist = []
    partlist = []
    while k < end:
        ss = k
        ee = k + win
        k = k + win
        wps_score = 0
        part = 0
        total = 0
        for r in bamfile.fetch(chrom, ss, ee):
            if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse and r.mapq > 30:
                _s = r.reference_start
                _e = abs(r.isize) + _s
                if _s <= ss and _e >= ee:
                    wps_score += 1
                    total += 1
                else:
                    wps_score -= 1
                    part += 1
        wpslist.append(wps_score)
        totallist.append(total)
        partlist.append(part)
    # print("-------------------")
    # print("start",start)
    # print("wps:",wpslist)
    # print("total:",totallist)
    # print("part:",partlist)
    wpslist = savgol_filter(wpslist,51,1)
    totallist = savgol_filter(totallist,51,1)
    partlist = savgol_filter(partlist,51,1)
    x = [i for i in range(len(wpslist))]
    plt.plot(x, wpslist,color = 'b',label='wps_score')
    plt.plot(x, totallist, color = 'g',label='total')
    plt.plot(x, partlist, color = 'r',label='part')
    plt.legend(loc='upper left')
    plt.show()
    # plt.savefig('/home/jiay/Desktop/OCR-1/051_wps_win10/' + str(start) + '.png', dpi=1200, format='png')
    # plt.clf()

    if count > 5:
        break
'''

'''
# WPS - win
# WPS chen
for seg in seglist:
    count += 1
    chrom = seg[0]
    start = seg[1]
    end = seg[2]
    win = 120
    bed1 = start - win
    bed2 = end + win
    length = bed2 - bed1
    array = np.zeros(length, dtype=np.int)
    array_total = np.zeros(length, dtype=np.int)
    array_part = np.zeros(length, dtype=np.int)
    for r in bamfile.fetch(chrom, bed1, bed2):
        if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse and r.mapq > 30:
            if r.isize < win or r.isize > 180:
                continue
            start = r.reference_start - bed1
            end = r.reference_start + r.isize - bed1

            # [$start+W/2,$end-W/2] WPS+1
            region1 = start + int(win / 2)
            region2 = end - int(win / 2)
            if region1 < 0:
                region1 = 0
            if region2 > length:
                region2 = length
            i = region1
            while i < region2:
                array[i] += 1
                array_total[i] += 1
                i += 1
            # [$start-w/2,$start-1+w/2] WPS-1
            region1 = start - int(win / 2)
            region2 = start + int(win / 2)
            if region1 < 0:
                region1 = 0
            if region2 > length:
                region2 = length
            i = region1
            while i < region2:
                array[i] -= 1
                array_part[i] += 1
                i += 1
            # [end-w/2+1,$end+w/2] WPS-1
            region1 = end - int(win / 2)
            region2 = end + int(win / 2)
            if region1 < 0:
                region1 = 0
            if region2 > length:
                region2 = length
            i = region1
            while i < region2:
                array[i] -= 1
                array_part[i] += 1
                i += 1
    # adjustWPS = AdjustWPS(array)
    lenth1 = len(array) - win
    bed1 += win
    bed2 -= win
    array = np.array(array[win: lenth1], dtype=np.float)
    total = np.array(array_total[win:lenth1], dtype=np.float)
    part = np.array(array_part[win:lenth1], dtype=np.float)
    wps = savgol_filter(array,51,1)
    total = savgol_filter(total,51,1)
    part = savgol_filter(part,51,1)
    # di = [part[i]/(part[i]+total[i])]
    di = np.zeros(len(wps),dtype=float)
    for i in range(len(wps)):
        if total[i] + part[i] != 0:
            di[i] = part[i] / (total[i]+part[i])
        else:
            di[i] = -1
        
    x = [i for i in range(len(wps))]
    k = 0
    wpslist = []
    totallist = []
    partlist = []
    # tt = 0
    # pp = 0
    xx = []
    di = []
    while k < seg[2]-seg[1]:
        ss = k
        ee = k + 180
        k = k + 90
        wpslist.append(np.sum(array[ss:ee]))
        totallist.append(np.sum(array_total[ss:ee]))
        partlist.append(np.sum(array_part[ss:ee]))
        sw = np.sum(array[ss:ee])
        st = np.sum(array_total[ss:ee])
        sp = np.sum(array_part[ss:ee])
        # print(st, sp)
        di.append(float(sp/(sp+st)))
        xx.append(ss)
    # plt.plot(x,wps,color = 'b',label='wps')
    # plt.plot(x,total,color = 'g',label='total')
    # plt.plot(x,part, color = 'r',label='part')
    # plt.legend(loc='upper left')
    # plt.show()
    # print(len(wpslist))

    # plt.subplot(211)
    # plt.plot(xx,wpslist,color = 'b',label='wps')
    # plt.plot(xx,totallist,color = 'g',label='total')
    # plt.plot(xx,partlist, color = 'r',label='part')
    # plt.legend(loc='upper left')
    # plt.subplot(212)
    # plt.plot(xx,di,color = 'y',label='fraction')
    # plt.legend(loc='upper left')
    # plt.show()
    if count > 5:
        break
'''