'''
x~N(u1,s1)
y~N(u2,s2)
'''

import sympy
import math
from math import e, inf
u1 = 10
u2 = 22
s1 = 5
s2 = 5

x = 21
t = sympy.Symbol('t')

mu = t * u1 + (1-t) * u2
sig = sympy.sqrt(t**2 * s1**2 + (1-t)**2 * s2**2)
# y = -1*sympy.log(math.sqrt(2*math.pi)*sig) - (x - mu)**2 / (2*sig**2) + sympy.log(t)
y = sympy.exp(-(x-mu)**2/(2*sig**2))/(math.sqrt(2*math.pi)*sig)
kk = 0
gg = float(-inf)
ttt = 0
while kk <= 1:
    re = y.evalf(subs={t:kk})
    if re > gg:
        gg = re
        ttt = kk
    kk += 0.01
    # print(re,mu.evalf(subs={t:kk}),sig.evalf(subs={t:kk}),kk)

print(gg,ttt)

# print(re)

# print(y)
# y_ = sympy.diff(y,t)
# print(y_)
# ttt = sympy.solve(y_,t)
# print(ttt)
# '''
# choose the second resolution
# '''
