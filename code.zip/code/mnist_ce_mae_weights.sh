#!/bin/bash
#SBATCH -J python_test
#SBATCH -p node
#SBATCH -o %j.out
#SBATCH -e %j.err
#SBATCH -n 1
export PATH="/share/apps/anaconda3/bin:$PATH"
source activate tensorflow
python mnist_ce_mae_weights.py