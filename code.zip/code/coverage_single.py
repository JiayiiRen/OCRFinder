import pysam as ps
import numpy as np
import collections
import matplotlib.pyplot as plt
from numpy.core.defchararray import array, center
import pysam as ps
import numpy as np
from collections import defaultdict
from scipy.ndimage.measurements import label
from sklearn.cluster import KMeans
import sys
from scipy.signal import savgol_filter
import math
from subprocess import call
import os.path


dic = {
    'TSSs_l':'./data/gene/low_expressed.bed',
    'location':'./data/gene/GRCh37.gene.bed',
    'bam':'./data/050.bam',
    'TSS_HK':'./data/gene/HK.bed'
    }

chr_to_id = {
    'chr1':'1','chr2':'2','chr3':'3','chr4':'4','chr5':'5','chr6':'6','chr7':'7','chr8':'8','chr9':'9','chr10':'10','chr11':'11','chr12':'12','chr13':'13','chr14':'14','chr15':'15','chr16':'16','chr17':'17','chr18':'18','chr19':'19','chr20':'20','chr21':'21','chr22':'22','chrX':'X','chrY':'Y'
}

class Gene:
    def __init__(self, chrom, start, end, strand, name):
        self.chrom = chrom
        self.start = start
        self.end = end
        self.strand = strand
        self.name = name

class TSS:
    def __init__(self, chrom, pos):
        self.chrom = chrom
        self.pos = pos

    def __str__(self):
        return str(self.chrom) + str(self.pos)

TSSs_l = []
with open(dic['TSSs_l'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == 'chr1':
            TSSs_l.append(TSS(chr_to_id[ll[0]],int(ll[1])))

TSS_HK = []
with open(dic['TSS_HK'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == '1':
            TSS_HK.append(TSS(ll[0], int(ll[1])+int(1000)))

up = 1000
down = 1000

# '''
#HK
count  = 0

TSSs_l = TSS_HK
# print(center_coverage)
for tss in TSSs_l:
    start = tss.pos - up
    end = tss.pos + down

    center_coverage = np.zeros((up+down)+1, dtype=float)
    TMP_COVERAGE_BED = open('./data/gene/'+tss.chrom+str(tss.pos)+'_center.bed','w')
    call(["samtools","depth","-a","-r",tss.chrom+":"+str(start)+"-"+str(end),dic['bam']], stdout=TMP_COVERAGE_BED)
    TMP_COVERAGE_BED.close()
    TMP_COVERAGE_BED_OUTPUT = open('./data/gene/'+tss.chrom+str(tss.pos)+'_center.bed','r')
    content = TMP_COVERAGE_BED_OUTPUT.readlines()
    for i, line in enumerate(content):
        co = float((line.split()[2]))
        if co == 0:
            continue
        # center_coverage[i] = math.exp(-1*co)# / control_coverage)
        center_coverage[i] += float(co)
    TMP_COVERAGE_BED_OUTPUT.close()
    call(["rm",'./data/gene/'+tss.chrom+str(tss.pos)+'_center.bed'])
    x = [i for i in range(len(center_coverage))]
    count += 1
    plt.subplot(610+count)
    plt.plot(x,[float(center_coverage[i]) for i in range(len(center_coverage))], color = 'r')
    

    if count > 5:
        break



plt.show()