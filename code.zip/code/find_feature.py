# import pysam as ps
# import numpy as np
# import collections
# import matplotlib.pyplot as plt
# from numpy.core.defchararray import array, center
# import pysam as ps
# import numpy as np
# from collections import defaultdict
# from scipy.ndimage.measurements import label, standard_deviation
# from scipy.stats.mstats_basic import kstest, normaltest
# from sklearn.cluster import KMeans
# import sys
# from scipy.signal import savgol_filter
# import math
# from subprocess import call
# import os.path
# from utils import Gene, TSS, Point
# from scipy import stats
# from sklearn import svm
# import sympy
# import math
# from math import e

# dic = {
#     'gene':'./data/gene/GRCh37.gene.bed',
#     'non_gene':'./data/gene/non_gene.bed',
#     'fasta':'/home/jiay/Desktop/hg19/hg19.fa',
#     'bam1':'./data/051.bam',
#     'bam2':'./data/051_2.bam',
#     'bam3':'./data/051_3.bam',
#     'bam123':'./data/051_123.bam',
#     'TSS_low':'./data/gene/low_expressed.bed',
#     'TSS_HK':'./data/gene/HK.bed',
#     'TSS_silent':'./data/gene/silent_gene_TSS.bed'
#     }
# chr_to_id = {
#     'chr1':'1','chr2':'2','chr3':'3','chr4':'4','chr5':'5','chr6':'6','chr7':'7','chr8':'8','chr9':'9','chr10':'10','chr11':'11','chr12':'12','chr13':'13','chr14':'14','chr15':'15','chr16':'16','chr17':'17','chr18':'18','chr19':'19','chr20':'20','chr21':'21','chr22':'22','chrX':'X','chrY':'Y'
# }
# up = 1000
# down = 1000

# bamfile = ps.AlignmentFile(dic['bam123'],'rb')

# TSS_HK = []
# with open(dic['TSS_HK'],'r') as f:
#     for line in f:
#         ll = line.strip().split('\t')
#         if ll[0] in ['1','2','3']:
#             TSS_HK.append(TSS(ll[0], int(ll[1])+int(1000)))

# # HK_long_array = np.zeros((len(TSS_HK), int(up+down)), dtype=int)
# # HK_short_array = np.zeros((len(TSS_HK), int(up+down)), dtype=int)
# length_dic = {}
# for j, tss in enumerate(TSS_HK):
#     chrom = tss.chrom
#     start = tss.pos - up
#     end = tss.pos + down
#     for r in bamfile.fetch(chrom, start-500, end + 500):
#         if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse:
#             ss = max(0, r.reference_start - start)
#             ee = min(r.reference_start - start + abs(r.isize), end - start)
#             # if r.isize <= 150:
#             #     for i in range(ss, ee):
#             #         HK_short_array[j][i] += 1
#             # if r.isize > 150:
#             #     for i in range(ss, ee):
#             #         HK_long_array[j][i] += 1
#         isize = abs(r.isize)
#         if isize > 300 or isize == 0:
#             continue
#         if ss <= 1000 and ee >= 1000:
#             if isize not in length_dic:
#                 length_dic[isize] = 1
#             else:
#                 length_dic[isize] += 1

# kk = sorted([k for k in length_dic])
# plt.bar(kk, [length_dic[k] for k in kk])
# plt.show()


import pysam as ps
import numpy as np
import collections
import matplotlib.pyplot as plt
from numpy.core.defchararray import array, center
import pysam as ps
import numpy as np
from collections import defaultdict
from scipy.ndimage.measurements import label, standard_deviation
from scipy.stats.mstats_basic import kstest, normaltest
from sklearn.cluster import KMeans
import sys
from scipy.signal import savgol_filter
import math
from subprocess import call
import os.path
from utils import Gene, TSS, Point
from scipy import stats
from sklearn import svm
import sympy
import math
from math import e

dic = {
    'gene':'./data/gene/GRCh37.gene.bed',
    'non_gene':'./data/gene/non_gene.bed',
    'fasta':'/home/jiay/Desktop/hg19/hg19.fa',
    'bam1':'./data/051.bam'
    }

fasta = ps.FastaFile(dic['fasta'])
bamfile = ps.AlignmentFile(dic['bam1'],'rb')
gene = []
with open(dic['gene'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] in ['1']:
            gene.append([ll[0],int(ll[1]),int(ll[2])])

gene = sorted(gene, key= lambda x: x[1])
non_gene = []
for i, gg in enumerate(gene):
    if i == 0 or i == len(gene) - 1:
        continue
    start = gg[1] - 4000
    end = gg[1] - 2000
    if start > gene[i-1][2]:
        if 'N' not in fasta.fetch('chr1',start,end):
            non_gene.append(['1', start, end])
    start = gg[2] + 2000
    end = gg[2] + 4000
    if end < gene[i+1][1]:
        if 'N' not in fasta.fetch('chr1',start,end):
            non_gene.append(['1', start, end])

length_dic = {}
for i, region in enumerate(non_gene):
    chrom = region[0]
    start = region[1]
    end = region[2]
    for r in bamfile.fetch(chrom, start-500, end+500):
        if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse:
            # if r.reference_start + abs(r.isize) < start or r.reference_start > end:
            #     continue
            ss = max(0, r.reference_start - start)
            ee = min(r.reference_start - start + abs(r.isize), end - start)
            isize = abs(r.isize)
            if isize > 300 or isize == 0:
                continue
            if ss <= 1000 and ee >= 1000:
                if isize not in length_dic:
                    length_dic[isize] = 1
                else:
                    length_dic[isize] += 1

kk = sorted([k for k in length_dic])
plt.bar(kk, [length_dic[k] for k in kk])
plt.show()