# from tensorflow.keras.datasets import cifar10
# import numpy as np
# from tensorflow.keras.utils import to_categorical
# import random
# from collections import defaultdict
# from sklearn.utils import shuffle
# import copy
# import random
# import math
# from matplotlib import pyplot as plt
# seed = 7
# np.random.seed(seed)
# def load_mnist(path):
#     with np.load(path, allow_pickle=True) as f:
#         x_train, y_train = f['x_train'], f['y_train']
#         x_test, y_test = f['x_test'], f['y_test']

#     return (x_train, y_train), (x_test, y_test)
# (x_train, y_train), (x_test, y_test) = load_mnist('../data/mnist.npz')

# # (x_train, y_train), (x_test, y_test) = cifar10.load_data()
# # x_train, y_train = shuffle(x_train,y_train, random_state=3927)
# # x_train = x_train.astype('float32')/255.0
# # x_test = x_test.astype('float32')/255.0

# num_pixels = x_train.shape[1]*x_train.shape[2]
# x_train = x_train.reshape(x_train.shape[0],num_pixels).astype('float32')
# x_test = x_test.reshape(x_test.shape[0],num_pixels).astype('float32')
# x_train = x_train/255.0
# x_test = x_test/255.0

# # img_x, img_y = x_train.shape[1], x_train.shape[2]
# # x_train = x_train.reshape(x_train.shape[0], img_x, img_y, 1)
# # x_test = x_test.reshape(x_test.shape[0], img_x, img_y, 1)
# # x_train = x_train.astype('float32')
# # x_test = x_test.astype('float32')
# # x_train /= 255.0
# # x_test /= 255.0

# noise_fraction = 0.4
# y_train_ori = copy.copy(y_train)
# y_id = np.array([i for i in range(len(y_train))])
# noise_ids = np.random.choice(y_id, int(len(y_train)*noise_fraction), replace=False)
# for id in noise_ids:
#     yy = y_train[id]
#     ra = np.random.randint(1,10)
#     yy_n = (ra+yy)%10

#     y_train[id] = yy_n
# clean_ids = []
# for id in range(len(x_train)):
#     if id in noise_ids:
#         continue
#     clean_ids.append(id)

# import tensorflow as tf
# from tensorflow import keras
# from tensorflow.keras import layers
# from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, Callback
# from sklearn.model_selection import KFold
# from tensorflow.keras import backend as K
# # def create_model():
# #     model = keras.models.Sequential()
# #     #add()添加新的训练层
# #     model.add(layers.Conv2D(32, kernel_size=(5,5), activation='relu', input_shape=(img_x, img_y, 1)))
# #     model.add(layers.MaxPool2D(pool_size=(2,2), strides=(2,2)))
# #     model.add(layers.Conv2D(64, kernel_size=(5,5), activation='relu'))
# #     model.add(layers.MaxPool2D(pool_size=(2,2), strides=(2,2)))
# #     model.add(layers.Flatten())
# #     model.add(layers.Dense(1000, activation='relu'))
# #     model.add(layers.Dense(10, activation='softmax'))
# #     return model
# def create_model():
#     model = keras.models.Sequential()
#     model.add(layers.Dense(num_pixels, activation='relu', input_dim=num_pixels))
#     model.add(layers.Dense(128, activation='relu'))
#     # model.add(layers.Dense(100, activation='relu'))
#     model.add(layers.Dense(10, activation='softmax'))
#     # adam = keras.optimizers.Adam(lr=1e-4)
#     # model.compile(optimizer=adam, loss='binary_crossentropy', metrics=['accuracy'])
#     return model
# # from tensorflow.keras.layers import Conv2D,MaxPooling2D,Dense,Dropout,Flatten
# # def create_model():
# #     model = keras.models.Sequential()
# #     model.add(Conv2D(filters=32,
# #                     kernel_size=(3,3),
# #                     input_shape=(32,32,3),
# #                     activation='relu',
# #                     padding='same'))
# #     # model.add(Dropout(0.25))
# #     model.add(MaxPooling2D(pool_size=(2,2)))
# #     model.add(Conv2D(filters=64, kernel_size=(3, 3),
# #                     activation='relu', padding='same'))
# #     # model.add(Dropout(0.25))
# #     model.add(MaxPooling2D(pool_size=(2, 2)))
# #     model.add(Conv2D(filters=128, kernel_size=(3, 3),
# #                     activation='relu', padding='same'))
# #     # model.add(Dropout(0.25))
# #     model.add(MaxPooling2D(pool_size=(2, 2)))
# #     model.add(Flatten())
# #     # model.add(Dropout(rate=0.50))　　　
# #     model.add(Dense(512, activation='relu'))
# #     # model.add(Dropout(rate=0.50))
# #     model.add(Dense(10, activation='softmax'))
# #     return model

# def CE_MAE(y_true, y_pred):
#     ce = K.categorical_crossentropy(y_true, y_pred)
#     mae = K.mean(K.abs(y_true-y_pred), axis=-1)
#     return ce + 2*mae

# im_model= create_model()
# adam = keras.optimizers.Adam(lr=1e-4)
# epochs = 100
# batchsize = 128
# im_model.compile(optimizer=adam, loss=keras.losses.MeanAbsoluteError(), metrics=['accuracy'])
# # im_model.compile(optimizer=adam, loss=keras.losses.CategoricalCrossentropy() , metrics=['accuracy'])
# # im_model.compile(optimizer=adam, loss=CE_MAE , metrics=['accuracy'])
# base_his = im_model.fit(x_train, to_categorical(y_train), epochs=epochs, batch_size=batchsize, verbose=2, validation_data=(x_test,to_categorical(y_test)))
# im_model.save('../model/ce_150.h5')
# import pickle
# with open('mnist_ce_150.txt','wb') as f:
#     pickle.dump(base_his.history, f)

# from tensorflow.keras.datasets import cifar10
# import numpy as np
# from tensorflow.keras.utils import to_categorical
# import random
# from collections import defaultdict
# from sklearn.utils import shuffle
# import copy
# import random
# import math
# from matplotlib import pyplot as plt
# seed = 7
# np.random.seed(seed)
# (x_train, y_train), (x_test, y_test) = cifar10.load_data()
# x_train, y_train = shuffle(x_train,y_train, random_state=3927)
# x_train = x_train.astype('float32')/255.0
# x_test = x_test.astype('float32')/255.0
# noise_fraction = 0.4
# y_train_ori = copy.copy(y_train)
# y_id = np.array([i for i in range(len(y_train))])
# noise_ids = np.random.choice(y_id, int(len(y_train)*noise_fraction), replace=False)
# for id in noise_ids:
#     yy = y_train[id]
#     ra = np.random.randint(1,10)
#     yy_n = (ra+yy)%10
#     y_train[id] = yy_n
# clean_ids = []
# for id in range(len(x_train)):
#     if id in noise_ids:
#         continue
#     clean_ids.append(id)
# y_train, y_train_ori = to_categorical(y_train), to_categorical(y_train_ori)
# '''create_model'''
# import tensorflow as tf
# from tensorflow import keras
# from tensorflow.keras import layers
# from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, Callback
# from sklearn.model_selection import KFold
# from tensorflow.keras import backend as K
# from tensorflow.keras.layers import Conv2D,MaxPooling2D,Dense,Dropout,Flatten
# def create_model():
#     model = keras.models.Sequential()
#     model.add(Conv2D(filters=32,
#                     kernel_size=(3,3),
#                     input_shape=(32,32,3),
#                     activation='relu',
#                     padding='same'))
#     # model.add(Dropout(0.25))
#     model.add(MaxPooling2D(pool_size=(2,2)))
#     model.add(Conv2D(filters=64, kernel_size=(3, 3),
#                     activation='relu', padding='same'))
#     # model.add(Dropout(0.25))
#     model.add(MaxPooling2D(pool_size=(2, 2)))
#     model.add(Conv2D(filters=128, kernel_size=(3, 3),
#                     activation='relu', padding='same'))
#     # model.add(Dropout(0.25))
#     model.add(MaxPooling2D(pool_size=(2, 2)))
#     model.add(Flatten())
#     # model.add(Dropout(rate=0.50))　　　
#     model.add(Dense(512, activation='relu'))
#     # model.add(Dropout(rate=0.50))
#     model.add(Dense(10, activation='softmax'))
#     return model
# nb_epochs = 150
# batchsize = 128
# '''improved coteaching'''
# loss_object = tf.keras.losses.BinaryCrossentropy(from_logits = False, reduction = tf.keras.losses.Reduction.NONE)
# def get_loss0(model, x, y):
#     pred_y = model(x, training=False)
#     return loss_object(tf.reshape(y, (-1,1)), tf.reshape(pred_y,(-1,1)))
# def focal_loss(y_true, y_pred):
#    gamma = 2.0
#    alpha = 0.5
#    pt_1 = tf.where(tf.equal(y_true, 1), y_pred, tf.ones_like(y_pred))
#    pt_0 = tf.where(tf.equal(y_true, 0), y_pred, tf.zeros_like(y_pred))
#    return -K.sum(alpha * K.pow(1. - pt_1, gamma) * K.log(pt_1))-K.sum((1-alpha) * K.pow( pt_0, gamma) * K.log(1. - pt_0))

# def CE_L1_loss(y_true, y_pred):
#     weight = 2
#     ce = K.categorical_crossentropy(y_true, y_pred)
#     mae = K.mean(K.abs(y_true-y_pred), axis=-1)
#     return ce + weight*mae    
# def get_loss1(model, x, y):
#     pred_y = model(x, training=False)
#     return loss_object(y_true = y, y_pred= np.array(pred_y).reshape(-1,1))
# def get_loss(y_t, y_p):
#     return K.categorical_crossentropy(y_t, y_p)

# l1_object = tf.keras.losses.BinaryCrossentropy(from_logits = False, reduction = tf.keras.losses.Reduction.SUM_OVER_BATCH_SIZE)     
# def loss_fn(yt, yp, ypp, ypp1, ypp2, gamma=0.5):
#     # l1 = tf.losses.binary_crossentropy(tf.reshape(yt,(-1,1)), tf.reshape(yp, (-1,1)))
#     l1 = K.categorical_crossentropy(yt, yp)
#     l2 = K.mean(K.square(ypp - (ypp1+ypp2)/2), axis=-1)
#     # p1 = K.square((ypp1 + ypp2)/2)
#     # p2 = K.square(1 - (ypp1 + ypp2)/2)
#     # p_s = p1/(p1+p2)
#     # l2 = K.square(ypp - p_s)
#     return K.mean(l1) + gamma * K.mean(l2, axis = -1)
# def loss_fn_new(yt, yp, ypp, yppp, gamma=0.5):
#     l1 = tf.losses.binary_crossentropy(tf.reshape(yt,(-1,1)), tf.reshape(yp, (-1,1)))
#     l2 = K.square(ypp - yppp)
#     return K.mean(l1) + gamma * K.mean(l2, axis = -1)
# # model.compile(optimizer=keras.optimizers.Adam(lr=1e-4), loss='binary_crossentropy', metrics=['accuracy'])
# lam = 0.3

# model_a = create_model()
# model_b = create_model()

# model_a.compile(optimizer=keras.optimizers.Adam(lr=1e-4, decay=1e-4), loss=CE_L1_loss, metrics=['accuracy'])
# model_b.compile(optimizer=keras.optimizers.Adam(lr=1e-4, decay=1e-4), loss=CE_L1_loss, metrics=['accuracy'])

# pre_epochs = 10
# x_train, y_train, y_train_ori = shuffle(x_train, y_train, y_train_ori)
# model_a.fit(x_train, y_train, epochs=pre_epochs, batch_size=batchsize, shuffle=True, verbose=0)
# model_b.fit(x_train, y_train, epochs=pre_epochs, batch_size=batchsize, shuffle=True, verbose=0)

# from tqdm import tqdm

# nb_batch = int(np.ceil(len(y_train) / batchsize))

# # train_dataset = tf.data.Dataset.from_tensor_slices((x_train, y_train))
# # train_dataset = train_dataset.shuffle(buffer_size=1024).batch(batchsize)
# optimizer_a = keras.optimizers.Adam(learning_rate=1e-4)
# optimizer_b = keras.optimizers.Adam(learning_rate=1e-4)
# pre_a = model_a(x_train,training=False).numpy()
# pre_b = model_b(x_train,training=False).numpy()
# loss_a = get_loss(y_train, pre_a).numpy()
# loss_b = get_loss(y_train, pre_b).numpy()
# for ep in tqdm(range(nb_epochs)):
#     p_a = model_a(x_train,training=False)
#     l_a = get_loss(y_train, p_a.numpy()).numpy()
#     pre_a = lam * p_a.numpy() + (1-lam) * pre_a
#     loss_a= lam * l_a + (1-lam) * loss_a
#     p_b = model_b(x_train,training=False)
#     l_b = get_loss(y_train, p_b.numpy()).numpy()
#     pre_b = lam * p_b.numpy() + (1-lam) * pre_b
#     loss_b = lam * l_b + (1-lam) * loss_b

#     mean_a = np.mean(loss_a)
#     data_ids_a = []
#     semi_ids_a = []
#     for id, ll in enumerate(loss_a):
#         if ll < mean_a:
#             data_ids_a.append(id)
#         else:
#             if (pre_a[id] -0.5) * (pre_b[id]-0.5) > 0:
#                 semi_ids_a.append(id)
#     mean_b = np.mean(loss_b)             
#     data_ids_b = []
#     semi_ids_b = []
#     for id, ll in enumerate(loss_b):
#         if ll < mean_b:
#             data_ids_b.append(id)
#         else:
#             if (pre_a[id]-0.5)*(pre_b[id]-0.5) > 0:
#                 semi_ids_b.append(id)
    

#     # pre_1 = K.square((pre_a + pre_b)/2)
#     # pre_2 = K.square(1-((pre_a + pre_b)/2))
#     # pre_sharpen = pre_1/(pre_1+pre_2)
#     perm = random.sample(range(len(y_train)),len(y_train))

#     for nb in range(nb_batch):
#         start = nb * batchsize
#         end = min((nb + 1) * batchsize, len(y_train))
#         # x_batch_train, y_batch_train = x_train[start:end], y_train[start:end]
#         tr_a_ids = []
#         ex_a_ids = []
#         tr_b_ids = []
#         ex_b_ids = []
#         # for id in range(start,end):
#         for id in perm[start:end]:
#             if id in data_ids_a:
#                 tr_a_ids.append(id)
#             elif id in semi_ids_a:
#                 ex_a_ids.append(id)
#             if id in data_ids_b:
#                 tr_b_ids.append(id)
#             elif id in semi_ids_b:
#                 ex_b_ids.append(id)
        

#         with tf.GradientTape() as tape_a:
#             logits_a = model_a(x_train[tr_b_ids], training=True)
#             log_a = model_a(x_train[ex_b_ids], training=True)
#             # loss_value_a = loss_fn_new(y_train[tr_b_ids], logits_a, log_a, pre_sharpen[ex_b_ids])
#             loss_value_a = loss_fn(y_train[tr_b_ids], logits_a, log_a, pre_a[ex_b_ids], pre_b[ex_b_ids])
#         grads_a = tape_a.gradient(loss_value_a, model_a.trainable_weights)
#         optimizer_a.apply_gradients(zip(grads_a, model_a.trainable_weights))

#         with tf.GradientTape() as tape_b:
#             logits_b = model_b(x_train[tr_a_ids], training=True)
#             log_b = model_b(x_train[ex_a_ids], training=True)
#             # loss_value_b = loss_fn_new(y_train[tr_a_ids], logits_b, log_b, pre_sharpen[ex_a_ids])
#             loss_value_b = loss_fn(y_train[tr_a_ids], logits_b, log_b, pre_a[ex_a_ids], pre_b[ex_a_ids])
#         grads_b = tape_b.gradient(loss_value_b, model_b.trainable_weights)
#         optimizer_b.apply_gradients(zip(grads_b, model_b.trainable_weights))
# # model_a.save('../model/mnist/model_a_hema27_150_ns.h5')
# # model_b.save('../model/mnist/model_b_hema27_150_ns.h5')


from tensorflow.keras.datasets import cifar10
import numpy as np
from tensorflow.keras.utils import to_categorical
import random
from collections import defaultdict
from sklearn.utils import shuffle
import copy
import random
import math
from matplotlib import pyplot as plt
import sys

seed = int(sys.argv[1])
n_round = sys.argv[2]
pattern = sys.argv[3]
nb_epochs = int(sys.argv[4])
lam = float(sys.argv[5])


# seed = 569
np.random.seed(seed)
# def load_mnist(path):
#     with np.load(path, allow_pickle=True) as f:
#         x_train, y_train = f['x_train'], f['y_train']
#         x_test, y_test = f['x_test'], f['y_test']

#     return (x_train, y_train), (x_test, y_test)
# (x_train, y_train), (x_test, y_test) = load_mnist('../data/mnist.npz')
# num_pixels = x_train.shape[1]*x_train.shape[2]
# x_train = x_train.reshape(x_train.shape[0],num_pixels).astype('float32')
# x_test = x_test.reshape(x_test.shape[0],num_pixels).astype('float32')
# x_train = x_train/255.0
# x_test = x_test/255.0
(x_train, y_train), (x_test, y_test) = cifar10.load_data()
x_train, y_train = shuffle(x_train,y_train, random_state=3927)
x_train = x_train.astype('float32')/255.0
x_test = x_test.astype('float32')/255.0

noise_fraction = 0.4
y_train_ori = copy.copy(y_train)
y_id = np.array([i for i in range(len(y_train))])
noise_ids = np.random.choice(y_id, int(len(y_train)*noise_fraction), replace=False)
for id in noise_ids:
    yy = y_train[id]
    ra = np.random.randint(1,10)
    yy_n = (ra+yy)%10

    y_train[id] = yy_n
clean_ids = []
for id in range(len(x_train)):
    if id in noise_ids:
        continue
    clean_ids.append(id)
y_train, y_train_ori, y_test = to_categorical(y_train), to_categorical(y_train_ori), to_categorical(y_test)

'''create_model'''
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, Callback
from sklearn.model_selection import KFold
from tensorflow.keras import backend as K
# def create_model():
#     model = keras.models.Sequential()
#     model.add(layers.Dense(num_pixels, activation='relu', input_dim=num_pixels))
#     model.add(layers.Dense(128, activation='relu'))
#     # model.add(layers.Dense(100, activation='relu'))
#     model.add(layers.Dense(10, activation='softmax'))
#     return model

'''create_model'''
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, Callback
from sklearn.model_selection import KFold
from tensorflow.keras import backend as K
from tensorflow.keras.layers import Conv2D,MaxPooling2D,Dense,Dropout,Flatten
def create_model():
    model = keras.models.Sequential()
    model.add(Conv2D(filters=32,
                    kernel_size=(3,3),
                    input_shape=(32,32,3),
                    activation='relu',
                    padding='same'))
    # model.add(Dropout(0.25))
    model.add(MaxPooling2D(pool_size=(2,2)))
    model.add(Conv2D(filters=64, kernel_size=(3, 3),
                    activation='relu', padding='same'))
    # model.add(Dropout(0.25))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Conv2D(filters=128, kernel_size=(3, 3),
                    activation='relu', padding='same'))
    # model.add(Dropout(0.25))
    model.add(MaxPooling2D(pool_size=(2, 2)))
    model.add(Flatten())
    # model.add(Dropout(rate=0.50))　　　
    model.add(Dense(512, activation='relu'))
    # model.add(Dropout(rate=0.50))
    model.add(Dense(10, activation='softmax'))
    return model
def CE_MAE(y_true, y_pred):
    ce = K.categorical_crossentropy(y_true, y_pred)
    mae = K.mean(K.abs(y_true-y_pred), axis=-1)
    return ce + 2*mae
x_train, y_train, y_train_ori = shuffle(x_train, y_train, y_train_ori)

# nb_epochs = 150
batchsize = 128
'''improved coteaching'''
loss_object = tf.keras.losses.BinaryCrossentropy(from_logits = False, reduction = tf.keras.losses.Reduction.NONE)
def get_loss0(model, x, y):
    pred_y = model(x, training=False)
    return loss_object(tf.reshape(y, (-1,1)), tf.reshape(pred_y,(-1,1)))
def focal_loss(y_true, y_pred):
   gamma = 2.0
   alpha = 0.5
   pt_1 = tf.where(tf.equal(y_true, 1), y_pred, tf.ones_like(y_pred))
   pt_0 = tf.where(tf.equal(y_true, 0), y_pred, tf.zeros_like(y_pred))
   return -K.sum(alpha * K.pow(1. - pt_1, gamma) * K.log(pt_1))-K.sum((1-alpha) * K.pow( pt_0, gamma) * K.log(1. - pt_0))

def CE_L1_loss(y_true, y_pred):
    weight = 2
    ce = K.categorical_crossentropy(y_true, y_pred)
    mae = K.mean(K.abs(y_true-y_pred), axis=-1)
    return ce #+ weight*mae    
def get_loss1(model, x, y):
    pred_y = model(x, training=False)
    return loss_object(y_true = y, y_pred= np.array(pred_y).reshape(-1,1))
def get_loss(y_t, y_p):
    return K.categorical_crossentropy(y_t, y_p)

def loss_fn(yt, yp, ypp, ypp1, ypp2, gamma=0.5):
    # l1 = tf.losses.binary_crossentropy(tf.reshape(yt,(-1,1)), tf.reshape(yp, (-1,1)))
    l1 = K.categorical_crossentropy(yt, yp)
    # l2 = K.mean(K.square(ypp - (ypp1+ypp2)/2), axis=-1)
    p1 = K.square((ypp1 + ypp2)/2)
    p_s = p1/K.sum(p1, axis=-1, keepdims=True)
    l2 = K.mean(K.square(ypp - p_s), axis=-1)
    # p2 = K.square(1 - (ypp1 + ypp2)/2)
    # p_s = p1/(p1+p2)
    # l2 = K.square(ypp - p_s)
    return K.mean(l1) + gamma * K.mean(l2, axis = -1)
def loss_fn_new(yt, yp, ypp, yppp, gamma=0.5):
    l1 = tf.losses.binary_crossentropy(tf.reshape(yt,(-1,1)), tf.reshape(yp, (-1,1)))
    l2 = K.square(ypp - yppp)
    return K.mean(l1) + gamma * K.mean(l2, axis = -1)
# model.compile(optimizer=keras.optimizers.Adam(lr=1e-4), loss='binary_crossentropy', metrics=['accuracy'])
# lam = 0.1

model_a = create_model()
model_b = create_model()

model_a.compile(optimizer=keras.optimizers.Adam(lr=1e-4, decay=1e-4), loss=CE_L1_loss, metrics=['accuracy'])
model_b.compile(optimizer=keras.optimizers.Adam(lr=1e-4, decay=1e-4), loss=CE_L1_loss, metrics=['accuracy'])
# model_a.compile(optimizer=keras.optimizers.Adam(lr=1e-4, decay=1e-4), loss=keras.losses.CategoricalCrossentropy(), metrics=['accuracy'])
# model_b.compile(optimizer=keras.optimizers.Adam(lr=1e-4, decay=1e-4), loss=keras.losses.CategoricalCrossentropy(), metrics=['accuracy'])


pre_epochs = 10
x_train, y_train, y_train_ori = shuffle(x_train, y_train, y_train_ori)
model_a.fit(x_train, y_train, epochs=pre_epochs, batch_size=batchsize, shuffle=True, verbose=2, validation_data=(x_test,y_test))
model_b.fit(x_train, y_train, epochs=pre_epochs, batch_size=batchsize, shuffle=True, verbose=2, validation_data=(x_test,y_test))
clean_details = np.argmax(y_train, axis=-1) == np.argmax(y_train_ori, axis=-1)
clean_details = np.array(clean_details, dtype=int)
from tqdm import tqdm
nb_batch = int(np.ceil(len(y_train) / batchsize))
optimizer_a = keras.optimizers.Adam(learning_rate=1e-4)
optimizer_b = keras.optimizers.Adam(learning_rate=1e-4)
# pre_a = model_a(x_train,training=False).numpy()
# pre_b = model_b(x_train,training=False).numpy()
pre_a = model_a.predict(x_train)
pre_b = model_b.predict(x_train)
loss_a = get_loss(y_train, pre_a).numpy()
loss_b = get_loss(y_train, pre_b).numpy()
val_acc = []
acc = []
clean_rate = []
import os
path = '../model/cifar10/%s/'%(n_round)
if not os.path.exists(path):
    os.mkdir(path)
path = '../model/cifar10/%s/%s/'%(n_round, pattern)
if not os.path.exists(path):
    os.mkdir(path)
for ep in tqdm(range(nb_epochs)):
    p_a = model_a.predict(x_train)
    l_a = get_loss(y_train, p_a).numpy()
    pre_a = lam*p_a + (1-lam)*pre_a
    loss_a= lam * l_a + (1-lam) * loss_a
    # loss_a = K.categorical_crossentropy(y_train, pre_a).numpy()

    p_b = model_b.predict(x_train)
    l_b = get_loss(y_train, p_b).numpy()
    pre_b = lam*p_b + (1-lam)*pre_b
    loss_b = lam * l_b + (1-lam) * loss_b
    # loss_b = K.categorical_crossentropy(y_train, pre_b).numpy()

    # if not os.path.exists(path+'loss_a/'):
    #     os.mkdir(path+'loss_a/')
    # np.save(path+'loss_a/'+'loss_a_'+str(ep)+'.npy', loss_a)

    mean_a = np.mean(loss_a)
    data_ids_a = []
    semi_ids_a = []
    for id, ll in enumerate(loss_a):
        if ll < mean_a:
            data_ids_a.append(id)
        else:
            # if (pre_a[id] -0.5) * (pre_b[id]-0.5) > 0:
            # if np.argmax(pre_a[id]) == np.argmax(pre_b[id]):
                semi_ids_a.append(id)
    # data_ids_a = loss_a < np.mean(loss_a)
    # semi_ids_a = loss_a >= np.mean(loss_a)
    
    # clean_rate.append((np.argmax(y_train[data_ids_a], axis=-1) == np.argmax(y_train_ori[data_ids_a], axis=-1)).sum()/len(y_train))
    clean_rate.append(clean_details[data_ids_a].sum()/len(data_ids_a))
    mean_b = np.mean(loss_b)             
    data_ids_b = []
    semi_ids_b = []
    for id, ll in enumerate(loss_b):
        if ll < mean_b:
            data_ids_b.append(id)
        else:
            # if (pre_a[id]-0.5)*(pre_b[id]-0.5) > 0:
            # if np.argmax(pre_a[id]) == np.argmax(pre_b[id]):
                semi_ids_b.append(id)
    

    # pre_1 = K.square((pre_a + pre_b)/2)
    # pre_2 = K.square(1-((pre_a + pre_b)/2))
    # pre_sharpen = pre_1/(pre_1+pre_2)
    perm = random.sample(range(len(y_train)),len(y_train))

    for nb in range(nb_batch):
        start = nb * batchsize
        end = min((nb + 1) * batchsize, len(y_train))
        # x_batch_train, y_batch_train = x_train[start:end], y_train[start:end]
        tr_a_ids = []
        ex_a_ids = []
        tr_b_ids = []
        ex_b_ids = []
        # for id in range(start,end):
        for id in perm[start:end]:
            if id in data_ids_a:
                tr_a_ids.append(id)
            elif id in semi_ids_a:
                ex_a_ids.append(id)
            if id in data_ids_b:
                tr_b_ids.append(id)
            elif id in semi_ids_b:
                ex_b_ids.append(id)
        

        with tf.GradientTape() as tape_a:
            logits_a = model_a(x_train[tr_b_ids], training=True)
            log_a = model_a(x_train[ex_b_ids], training=True)
            # loss_value_a = loss_fn_new(y_train[tr_b_ids], logits_a, log_a, pre_sharpen[ex_b_ids])
            loss_value_a = loss_fn(y_train[tr_b_ids], logits_a, log_a, pre_a[ex_b_ids], pre_b[ex_b_ids])
        grads_a = tape_a.gradient(loss_value_a, model_a.trainable_weights)
        optimizer_a.apply_gradients(zip(grads_a, model_a.trainable_weights))

        with tf.GradientTape() as tape_b:
            logits_b = model_b(x_train[tr_a_ids], training=True)
            log_b = model_b(x_train[ex_a_ids], training=True)
            # loss_value_b = loss_fn_new(y_train[tr_a_ids], logits_b, log_b, pre_sharpen[ex_a_ids])
            loss_value_b = loss_fn(y_train[tr_a_ids], logits_b, log_b, pre_a[ex_a_ids], pre_b[ex_a_ids])
        grads_b = tape_b.gradient(loss_value_b, model_b.trainable_weights)
        optimizer_b.apply_gradients(zip(grads_b, model_b.trainable_weights))
    val_acc.append(model_a.evaluate(x_test, y_test, batch_size=batchsize)[1])
    acc.append(model_a.evaluate(x_train, y_train, batch_size=batchsize)[1])

model_a.save(path+'model_a_100.h5')
model_b.save(path+'model_b_100.h5')
np.save(path+'val_acc_100.npy', np.array(val_acc))
np.save(path+'acc_100.npy', np.array(acc))
np.save(path+'clean_rate_100.npy', np.array(clean_rate))

# from tensorflow.keras.datasets import cifar10
# import numpy as np
# from tensorflow.keras.utils import to_categorical
# import random
# from collections import defaultdict
# from sklearn.utils import shuffle
# import copy
# import random
# import math
# from matplotlib import pyplot as plt
# seed = 7
# np.random.seed(seed)
# # def load_mnist(path):
# #     with np.load(path, allow_pickle=True) as f:
# #         x_train, y_train = f['x_train'], f['y_train']
# #         x_test, y_test = f['x_test'], f['y_test']

# #     return (x_train, y_train), (x_test, y_test)
# # (x_train, y_train), (x_test, y_test) = load_mnist('../data/mnist.npz')
# # num_pixels = x_train.shape[1]*x_train.shape[2]
# # x_train = x_train.reshape(x_train.shape[0],num_pixels).astype('float32')
# # x_test = x_test.reshape(x_test.shape[0],num_pixels).astype('float32')
# # x_train = x_train/255.0
# # x_test = x_test/255.0
# (x_train, y_train), (x_test, y_test) = cifar10.load_data()
# x_train, y_train = shuffle(x_train,y_train, random_state=3927)
# x_train = x_train.astype('float32')/255.0
# x_test = x_test.astype('float32')/255.0

# noise_fraction = 0.4
# y_train_ori = copy.copy(y_train)
# y_id = np.array([i for i in range(len(y_train))])
# noise_ids = np.random.choice(y_id, int(len(y_train)*noise_fraction), replace=False)
# for id in noise_ids:
#     yy = y_train[id]
#     ra = np.random.randint(1,10)
#     yy_n = (ra+yy)%10

#     y_train[id] = yy_n
# clean_ids = []
# for id in range(len(x_train)):
#     if id in noise_ids:
#         continue
#     clean_ids.append(id)
# y_train, y_train_ori, y_test = to_categorical(y_train), to_categorical(y_train_ori), to_categorical(y_test)

# '''create_model'''
# import tensorflow as tf
# from tensorflow import keras
# from tensorflow.keras import layers
# from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, Callback
# from sklearn.model_selection import KFold
# from tensorflow.keras import backend as K
# '''create_model'''
# import tensorflow as tf
# from tensorflow import keras
# from tensorflow.keras import layers
# from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, Callback
# from sklearn.model_selection import KFold
# from tensorflow.keras import backend as K
# from tensorflow.keras.layers import Conv2D,MaxPooling2D,Dense,Dropout,Flatten
# def create_model():
#     model = keras.models.Sequential()
#     model.add(Conv2D(filters=32,
#                     kernel_size=(3,3),
#                     input_shape=(32,32,3),
#                     activation='relu',
#                     padding='same'))
#     # model.add(Dropout(0.25))
#     model.add(MaxPooling2D(pool_size=(2,2)))
#     model.add(Conv2D(filters=64, kernel_size=(3, 3),
#                     activation='relu', padding='same'))
#     # model.add(Dropout(0.25))
#     model.add(MaxPooling2D(pool_size=(2, 2)))
#     model.add(Conv2D(filters=128, kernel_size=(3, 3),
#                     activation='relu', padding='same'))
#     # model.add(Dropout(0.25))
#     model.add(MaxPooling2D(pool_size=(2, 2)))
#     model.add(Flatten())
#     # model.add(Dropout(rate=0.50))　　　
#     model.add(Dense(512, activation='relu'))
#     # model.add(Dropout(rate=0.50))
#     model.add(Dense(10, activation='softmax'))
#     return model
# def CE_MAE(y_true, y_pred):
#     ce = K.categorical_crossentropy(y_true, y_pred)
#     mae = K.mean(K.abs(y_true-y_pred), axis=-1)
#     return ce + 2*mae
# x_train, y_train, y_train_ori = shuffle(x_train, y_train, y_train_ori)

# nb_epochs = 150
# batchsize = 128
# '''co-teaching'''
# m_a = create_model()
# m_b = create_model()
# def get_loss(y_t, y_p):
#     return K.categorical_crossentropy(y_t, y_p)
# m_a.compile(optimizer=keras.optimizers.Adam(lr=1e-4, decay=1e-4), loss=CE_MAE, metrics=['accuracy'])
# m_b.compile(optimizer=keras.optimizers.Adam(lr=1e-4, decay=1e-4), loss=CE_MAE, metrics=['accuracy'])

# pre_epochs = 10
# pha = m_a.fit(x_train, y_train, epochs=pre_epochs, batch_size=batchsize, shuffle=True, verbose=2, validation_data=(x_test,y_test))
# phb = m_b.fit(x_train, y_train, epochs=pre_epochs, batch_size=batchsize, shuffle=True, verbose=2, validation_data=(x_test,y_test))

# optimizer_a = keras.optimizers.Adam(learning_rate=1e-4)
# optimizer_b = keras.optimizers.Adam(learning_rate=1e-4)
# nb_batch = int(np.ceil(len(y_train)/batchsize))
# from tqdm import tqdm
# for ep in tqdm(range(nb_epochs)):
#     perm = random.sample(range(len(y_train)),len(y_train))
#     for nb in range(nb_batch):
#         start = nb * batchsize
#         end = (nb + 1) * batchsize
#         input_batch, y_batch_train, y_batch_train_ori = x_train[perm[start:end]], y_train[perm[start:end]], y_train_ori[perm[start:end]]
#         # input_1_batch, input_2_batch, y_batch_train = input_1[start:end], input_2[start:end], y_train[start:end]

#         p_a = m_a(input_batch,training=False)
#         loss_a = get_loss(y_batch_train, p_a).numpy()

#         p_b = m_b(input_batch,training=False)
#         loss_b = get_loss(y_batch_train, p_b).numpy()
#         a_tmp, loss_a_ind_sorted = tf.nn.top_k(-loss_a, len(loss_a))
#         b_tmp, loss_b_ind_sorted = tf.nn.top_k(-loss_b, len(loss_b))
#         train_a_id = []
#         train_b_id = []
#         loss_a_ind_sorted = loss_a_ind_sorted.numpy()
#         loss_b_ind_sorted = loss_b_ind_sorted.numpy()
#         new_data_size = int(len(y_batch_train)*(1-rate_schedule[ep]))

#         for k in range(new_data_size):
#             train_a_id.append(loss_b_ind_sorted[k])
#             train_b_id.append(loss_a_ind_sorted[k])
   
#         with tf.GradientTape() as tape_a:
#             # logits_a = m_a(x_batch_train[train_a_id], training=True)
#             logits_a = m_a(input_batch[train_a_id], training=True)
#             loss_value_a = get_loss(y_batch_train[train_a_id], logits_a)
#         grads_a = tape_a.gradient(loss_value_a, m_a.trainable_weights)
#         optimizer_a.apply_gradients(zip(grads_a, m_a.trainable_weights))

#         with tf.GradientTape() as tape_b:
#             logits_b = m_b(input_batch[train_b_id], training=True)
#             loss_value_b = get_loss(y_batch_train[train_b_id], logits_b)
#         grads_b = tape_b.gradient(loss_value_b, m_b.trainable_weights)
#         optimizer_b.apply_gradients(zip(grads_b, m_b.trainable_weights))
#     m_a.evaluate(x_test, y_test, batch_size=batchsize)
# # m_a.save('../model/m_a_hk27_150_s.h5')
# # m_b.save('../model/m_b_hk27_150_s.h5')


# '''co-teaching'''
# m_a = create_model()
# m_b = create_model()
# def get_loss(y_t, y_p):
#     return K.categorical_crossentropy(y_t, y_p)
# m_a.compile(optimizer=keras.optimizers.Adam(lr=1e-4, decay=1e-4), loss='categorical_crossentropy', metrics=['accuracy'])
# m_b.compile(optimizer=keras.optimizers.Adam(lr=1e-4, decay=1e-4), loss='categorical_crossentropy', metrics=['accuracy'])

# optimizer_a = keras.optimizers.Adam(learning_rate=1e-4)
# optimizer_b = keras.optimizers.Adam(learning_rate=1e-4)
# exponent = 1 #exponent of the forget rate. This parameter is equal to c in Tc for R(T) in Co-teaching paper.
# num_gradual = 30 #how many epochs for linear drop rate. This parameter is equal to Tk for R(T) in Co-teaching paper.
# forget_rate = 0.4
# rate_schedule = np.ones(nb_epochs)*forget_rate
# rate_schedule[:num_gradual] = np.linspace(0, forget_rate**exponent, num_gradual)
# nb_batch = int(np.ceil(len(y_train)/batchsize))
# from tqdm import tqdm
# for ep in tqdm(range(nb_epochs)):
#     perm = random.sample(range(len(y_train)),len(y_train))
#     for nb in range(nb_batch):
#         start = nb * batchsize
#         end = (nb + 1) * batchsize
#         input_batch, y_batch_train, y_batch_train_ori = x_train[perm[start:end]], y_train[perm[start:end]], y_train_ori[perm[start:end]]
#         # input_1_batch, input_2_batch, y_batch_train = input_1[start:end], input_2[start:end], y_train[start:end]

#         p_a = m_a(input_batch,training=False)
#         loss_a = get_loss(y_batch_train, p_a).numpy()

#         p_b = m_b(input_batch,training=False)
#         loss_b = get_loss(y_batch_train, p_b).numpy()
#         a_tmp, loss_a_ind_sorted = tf.nn.top_k(-loss_a, len(loss_a))
#         b_tmp, loss_b_ind_sorted = tf.nn.top_k(-loss_b, len(loss_b))
#         train_a_id = []
#         train_b_id = []
#         loss_a_ind_sorted = loss_a_ind_sorted.numpy()
#         loss_b_ind_sorted = loss_b_ind_sorted.numpy()
#         new_data_size = int(len(y_batch_train)*(1-rate_schedule[ep]))

#         for k in range(new_data_size):
#             train_a_id.append(loss_b_ind_sorted[k])
#             train_b_id.append(loss_a_ind_sorted[k])
   
#         with tf.GradientTape() as tape_a:
#             # logits_a = m_a(x_batch_train[train_a_id], training=True)
#             logits_a = m_a(input_batch[train_a_id], training=True)
#             loss_value_a = get_loss(y_batch_train[train_a_id], logits_a)
#         grads_a = tape_a.gradient(loss_value_a, m_a.trainable_weights)
#         optimizer_a.apply_gradients(zip(grads_a, m_a.trainable_weights))

#         with tf.GradientTape() as tape_b:
#             logits_b = m_b(input_batch[train_b_id], training=True)
#             loss_value_b = get_loss(y_batch_train[train_b_id], logits_b)
#         grads_b = tape_b.gradient(loss_value_b, m_b.trainable_weights)
#         optimizer_b.apply_gradients(zip(grads_b, m_b.trainable_weights))
#     m_a.evaluate(x_test, y_test, batch_size=batchsize)
# # m_a.save('../model/m_a_hk27_150_s.h5')
# # m_b.save('../model/m_b_hk27_150_s.h5')