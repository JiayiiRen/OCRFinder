import pysam as ps
import numpy as np
import collections
import matplotlib.pyplot as plt
from numpy.core.defchararray import array, center, title
import pysam as ps
import numpy as np
from collections import defaultdict
from scipy.ndimage.measurements import label
from sklearn.cluster import KMeans
import sys
from scipy.signal import savgol_filter
import math
from subprocess import call
import os.path
from utils import Gene, TSS, Point
from tqdm import tqdm

dic = {
    'TSSs_l':'./data/gene/low_expressed.bed',
    'location':'./data/gene/GRCh37.gene.bed',
    'bam':'./data/051_123.bam',
    'TSS_HK':'./data/gene/HK.bed',
    'TSS_silent':'./data/gene/silent_gene_TSS.bed',
    'Lung':'./excel/Lung.bed',
    'Tcell':'./excel/Tcell.bed',
    'Liver':'./excel/Liver.bed'
    }

chr_to_id = {
    'chr1':'1','chr2':'2','chr3':'3','chr4':'4','chr5':'5','chr6':'6','chr7':'7','chr8':'8','chr9':'9','chr10':'10','chr11':'11','chr12':'12','chr13':'13','chr14':'14','chr15':'15','chr16':'16','chr17':'17','chr18':'18','chr19':'19','chr20':'20','chr21':'21','chr22':'22','chrX':'X','chrY':'Y'
}

bamfile = ps.AlignmentFile(dic['bam'],'rb')

up = 150
down = 150

length_cutoff = 140

count = 0
TSS_silent = []
with open(dic['TSS_silent'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] in ['1','2','3']:
            TSS_silent.append(TSS(ll[0], int(ll[1])+int(1000)))
# print(len(TSS_silent))
TSS_HK = []
with open(dic['TSS_HK'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] in ['1','2','3']:
            TSS_HK.append(TSS(ll[0], int(ll[1])+int(1000)))

TSSs_l = []
with open(dic['Liver'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        # if ll[0] in ['chr1']:
        #     TSSs_l.append(TSS(chr_to_id[ll[0]],int(ll[1])))
        if ll[0] in ['1','2','3']:
            TSSs_l.append(TSS(ll[0],int(ll[1])))


