from subprocess import call
seeds = [7, 81, 569, 2337, 392, 6731, 27, 489, 271, 382, 690, 873, 3731, 5379]
pp = ['semi','pre_train','ensemble','lam_0.1','lam_0.2','lam_0.4','lam_0.3','lam_0.5','lam_0.6','lam_0.7','lam_0.8','lam_0.9']
for i in range(3):
    n_round = i
    seed = seeds[i]
    lam = 1
    pattern = 'ensemble'
    epochs = 150
    cmd = 'python mnist_ensemble.py %s %s %s %s %s'%(seed, n_round, pattern, epochs, lam)
    print(cmd)
    call(cmd, shell=True)
# for i in range(3):
#     n_round = i
#     seed = seeds[i]
#     lam = 0.3
#     pattern = 'pre_train'
#     epochs = 150
#     cmd = 'python mnist_pretrain.py %s %s %s %s %s'%(seed, n_round, pattern, epochs, lam)
#     print(cmd)
#     call(cmd, shell=True)
# for i in range(3):
#     n_round = i
#     seed = seeds[i]
#     lam = 0.4
#     pattern = 'lam_0.4'
#     epochs = 150
#     cmd = 'python mnist.py %s %s %s %s %s'%(seed, n_round, pattern, epochs, lam)
#     print(cmd)
#     call(cmd, shell=True)

