import pysam as ps
import numpy as np
import collections
import matplotlib.pyplot as plt
from numpy.core.defchararray import array, center
import pysam as ps
import numpy as np
from collections import defaultdict
from scipy.ndimage.measurements import label
from sklearn.cluster import KMeans
import sys
from scipy.signal import savgol_filter
import math
from subprocess import call
import os.path
from utils import Gene, TSS, Point

dic = {
    'TSSs_l':'./data/gene/low_expressed.bed',
    'location':'./data/gene/GRCh37.gene.bed',
    'bam':'./data/050.bam',
    'TSS_HK':'./data/gene/HK.bed',
    'TSS_silent':'./data/gene/silent_gene_TSS.bed'
    }

chr_to_id = {
    'chr1':'1','chr2':'2','chr3':'3','chr4':'4','chr5':'5','chr6':'6','chr7':'7','chr8':'8','chr9':'9','chr10':'10','chr11':'11','chr12':'12','chr13':'13','chr14':'14','chr15':'15','chr16':'16','chr17':'17','chr18':'18','chr19':'19','chr20':'20','chr21':'21','chr22':'22','chrX':'X','chrY':'Y'
}


bamfile = ps.AlignmentFile(dic['bam'],'rb')

TSS_silent = []
with open(dic['TSS_silent'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == '1':
            TSS_silent.append(TSS(ll[0], int(ll[1])+int(1000)))

TSS_HK = []
with open(dic['TSS_HK'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == '1':
            TSS_HK.append(TSS(ll[0], int(ll[1])+int(1000)))

TSSs_l = TSS_silent
count = 0
win0 = 200
wps_fraction = np.zeros((len(TSSs_l), int(2*2000/win0-1)), dtype=float)

for j, tss in enumerate(TSSs_l):
    win = 20
    chrom = tss.chrom
    start = tss.pos - 1000
    end = tss.pos + 1000
    length = end-start
    wps_list_total = np.zeros(length, dtype=float)
    wps_list_part = np.zeros(length, dtype=float)
    for r in bamfile.fetch(chrom, start, end):
        if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse and r.mapq > 30:
            if r.isize < win or r.isize > 180:
                continue
            ss = r.reference_start - start
            ee = r.reference_start + abs(r.isize) - start

            # wps_total
            region1 = int(max(0, ss + win/2))
            region2 = int(min(ee - win/2, end-start))
            i = region1
            while i < region2:
                wps_list_total[i] += 1
                i = i+1
            # wps_part
            region1 = int(max(0, ss - win/2))
            region2 = int(min(end-start, ss + win/2))
            i = region1
            while i < region2:
                wps_list_part[i] += 1
                i = i + 1
            # wps_part
            region1 = int(max(ee - win/2, 0))
            region2 = int(min(ee + win/2, end-start))
            i = region1
            while i < region2:
                wps_list_part[i] += 1
                i = i+1
    # plt.plot([i for i in range(len(wps_list_total))], wps_list_total,color = 'r')
    # plt.plot([i for i in range(len(wps_list_part))], wps_list_part, color = 'b')
    for i in range(len(wps_list_part)):
        if wps_list_part[i] == 0:
            k = i
            while k > 0 and wps_list_part[k] == 0:
                k = k - 1
            p = i
            while p < len(wps_list_part) - 1 and wps_list_part[p] == 0:
                p = p + 1
            wps_list_part[i] = (wps_list_part[k] + wps_list_part[p]) / 2
        
        if wps_list_total[i] == 0:
            k = i
            while k > 0 and wps_list_total[k] == 0:
                k = k - 1
            p = i
            while p < len(wps_list_part) - 1 and wps_list_total[p] == 0:
                p = p + 1
            wps_list_total[i] = (wps_list_total[k] + wps_list_total[p]) / 2
    k = start
    i = 0
    while True:
        ss = int(k) - start
        ee = int(k + win0) - start
        if ee + start > end:
            break
        k = k + win0 / 2
        st = np.sum(wps_list_total[ss:ee])
        sp = np.sum(wps_list_part[ss:ee])
        # print(ss,ee)
        if st + sp != 0:
            wps_fraction[j][i] = float(sp / (st+sp))
        i += 1
    # print("i=",i)
    # print(wps_fraction)
plt.plot([i for i in range(len(wps_fraction[0]))], [np.mean(wps_fraction[:,i]) for i in range(len(wps_fraction[0]))], color = 'b')
plt.plot([i for i in range(len(wps_fraction[0]))], [np.std(wps_fraction[:,i],ddof=1) for i in range(len(wps_fraction[0]))], color = 'b',linestyle=':')



TSSs_l = TSS_HK
count = 0
win0 = 200
wps_fraction = np.zeros((len(TSSs_l), int(2*2000/win0-1)), dtype=float)

for j, tss in enumerate(TSSs_l):
    win = 20
    chrom = tss.chrom
    start = tss.pos - 1000
    end = tss.pos + 1000
    length = end-start
    wps_list_total = np.zeros(length, dtype=float)
    wps_list_part = np.zeros(length, dtype=float)
    for r in bamfile.fetch(chrom, start, end):
        if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse and r.mapq > 30:
            if r.isize < win or r.isize > 180:
                continue
            ss = r.reference_start - start
            ee = r.reference_start + abs(r.isize) - start

            # wps_total
            region1 = int(max(0, ss + win/2))
            region2 = int(min(ee - win/2, end-start))
            i = region1
            while i < region2:
                wps_list_total[i] += 1
                i = i+1
            # wps_part
            region1 = int(max(0, ss - win/2))
            region2 = int(min(end-start, ss + win/2))
            i = region1
            while i < region2:
                wps_list_part[i] += 1
                i = i + 1
            # wps_part
            region1 = int(max(ee - win/2, 0))
            region2 = int(min(ee + win/2, end-start))
            i = region1
            while i < region2:
                wps_list_part[i] += 1
                i = i+1
    # plt.plot([i for i in range(len(wps_list_total))], wps_list_total,color = 'r')
    # plt.plot([i for i in range(len(wps_list_part))], wps_list_part, color = 'b')
    for i in range(len(wps_list_part)):
        if wps_list_part[i] == 0:
            k = i
            while k > 0 and wps_list_part[k] == 0:
                k = k - 1
            p = i
            while p < len(wps_list_part) - 1 and wps_list_part[p] == 0:
                p = p + 1
            wps_list_part[i] = (wps_list_part[k] + wps_list_part[p]) / 2
        
        if wps_list_total[i] == 0:
            k = i
            while k > 0 and wps_list_total[k] == 0:
                k = k - 1
            p = i
            while p < len(wps_list_part) - 1 and wps_list_total[p] == 0:
                p = p + 1
            wps_list_total[i] = (wps_list_total[k] + wps_list_total[p]) / 2
    k = start
    i = 0
    while True:
        ss = int(k) - start
        ee = int(k + win0) - start
        if ee + start > end:
            break
        k = k + win0 / 2
        st = np.sum(wps_list_total[ss:ee])
        sp = np.sum(wps_list_part[ss:ee])
        # print(ss,ee)
        if st + sp != 0:
            wps_fraction[j][i] = float(sp / (st+sp))
        i += 1

        # if wps_list_total[i] == 0:
        #     k = i
        #     while k > 0 and wps_list_total[k] == 0:
        #         k = k - 1
        #     p = i
        #     while p < len(wps_list_part) - 1 and wps_list_total[p] == 0:
        #         p = p + 1
        #     wps_list_total[i] = (wps_list_total[k] + wps_list_total[p]) / 2
plt.plot([i for i in range(len(wps_fraction[0]))], [np.mean(wps_fraction[:,i]) for i in range(len(wps_fraction[0]))], color = 'r')
plt.plot([i for i in range(len(wps_fraction[0]))], [np.std(wps_fraction[:,i],ddof=1) for i in range(len(wps_fraction[0]))], color = 'r',linestyle=':')
plt.show()

    





