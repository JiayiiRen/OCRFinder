# from fraction_general import TSSs_l
# from matplotlib.lines import _LineStyle
import pysam as ps
import numpy as np
import collections
import matplotlib.pyplot as plt
from numpy.core.defchararray import array, center
import pysam as ps
import numpy as np
from collections import defaultdict
from scipy.ndimage.measurements import label
from sklearn.cluster import KMeans
import sys
from scipy.signal import savgol_filter
import math
from subprocess import call
import os.path
from utils import Gene, TSS, Point

dic = {
    'TSSs_l':'./data/gene/low_expressed.bed',
    'location':'./data/gene/GRCh37.gene.bed',
    'bam':'./data/051.bam',
    'TSS_HK':'./data/gene/HK.bed',
    'TSS_silent':'./data/gene/silent_gene_TSS.bed'
    }

chr_to_id = {
    'chr1':'1','chr2':'2','chr3':'3','chr4':'4','chr5':'5','chr6':'6','chr7':'7','chr8':'8','chr9':'9','chr10':'10','chr11':'11','chr12':'12','chr13':'13','chr14':'14','chr15':'15','chr16':'16','chr17':'17','chr18':'18','chr19':'19','chr20':'20','chr21':'21','chr22':'22','chrX':'X','chrY':'Y'
}


bamfile = ps.AlignmentFile(dic['bam'],'rb')

# TSSs_l = []
# with open(dic['TSSs_l'],'r') as f:
#     for line in f:
#         ll = line.strip().split('\t')
#         if ll[0] == 'chr1':
#             TSSs_l.append(TSS(chr_to_id[ll[0]],int(ll[1])))
TSS_silent = []
with open(dic['TSS_silent'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == '1':
            TSS_silent.append(TSS(ll[0], int(ll[1])+int(1000)))

TSS_HK = []
with open(dic['TSS_HK'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == '1':
            TSS_HK.append(TSS(ll[0], int(ll[1])+int(1000)))

p = 25
TSS_silent = TSS_silent[0:p]
TSS_HK = TSS_HK[0:p]

win = 200
TSSs_l = TSS_silent
win_fraction_l = np.zeros((len(TSSs_l), int(2*2000/win-1)), dtype=float)


for j, tss in enumerate(TSSs_l):
    chrom = tss.chrom
    start = tss.pos - 1000
    end = tss.pos + 1000
    
    plist = []
    for r in bamfile.fetch(chrom, start, end):
         if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse and r.mapq > 30:
            ss = r.reference_start
            ee = abs(r.isize)
            plist.append(Point(ss, ee))
    plist = sorted(plist, key= lambda a: a.x)
    k = start
    num_win = []
    i = 0
    while True:
        # print(i)
        ss = k
        ee = k + win
        if ee > end:
            break
        k = k + win / 2
        _set = [p for p in plist if ss <= p.x <= ee ] # ss <= p.x <= ee and p.x + p.y <= ee
        # if len(_set) == 0:
        #     continue
        s1 = [p for p in _set if p.y <= 140]
        s2 = [p for p in _set if p.y > 140]
        if len(s1) + len(s2) != 0:
            fraction = float(len(s1)/(len(s1)+len(s2)))
            win_fraction_l[j][i] = fraction
        i += 1

        # if wps_list_total[i] == 0:
        #     k = i
        #     while k > 0 and wps_list_total[k] == 0:
        #         k = k - 1
        #     p = i
        #     while p < len(wps_list_part) - 1 and wps_list_total[p] == 0:
        #         p = p + 1
        #     wps_list_total[i] = (wps_list_total[k] + wps_list_total[p]) / 2
plt.plot([i for i in range(len(win_fraction_l[0]))], savgol_filter([np.mean(win_fraction_l[:,i]) for i in range(len(win_fraction_l[0]))],3,1), color = 'b')
plt.plot([i for i in range(len(win_fraction_l[0]))], savgol_filter([np.std(win_fraction_l[:,i],ddof=1) for i in range(len(win_fraction_l[0]))],3,1), color = 'b',linestyle=':')

win_fraction_HK = np.zeros((len(TSS_HK), int(2*2000/win-1)), dtype=float)
for j, tss in enumerate(TSS_HK):
    chrom = tss.chrom
    start = tss.pos - 1000
    end = tss.pos + 1000
    
    plist = []
    for r in bamfile.fetch(chrom, start, end):
         if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse and r.mapq > 30:
            ss = r.reference_start
            ee = abs(r.isize)
            plist.append(Point(ss, ee))
    plist = sorted(plist, key= lambda a: a.x)
    k = start
    num_win = []
    i = 0
    while True:
        ss = k
        ee = k + win
        if ee > end:
            break
        k = k + win / 2
        _set = [p for p in plist if ss <= p.x <= ee ] # ss <= p.x <= ee and p.x + p.y <= ee
        s1 = [p for p in _set if p.y <= 140]
        s2 = [p for p in _set if p.y > 140]
        if len(s1) + len(s2) != 0:
            fraction = float(len(s1)/(len(s1)+len(s2)))
            win_fraction_HK[j][i] += fraction
        i += 1

plt.plot([i for i in range(len(win_fraction_HK[0]))], savgol_filter([np.mean(win_fraction_HK[:,i]) for i in range(len(win_fraction_HK[0]))],3,1), color = 'r')
plt.plot([i for i in range(len(win_fraction_HK[0]))], savgol_filter([np.std(win_fraction_HK[:,i]) for i in range(len(win_fraction_HK[0]))],3,1), color = 'r',linestyle=':')



plt.title('fraction-general')
plt.show()
