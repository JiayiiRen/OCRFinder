# from fraction_general import TSSs_l
# from matplotlib.lines import _LineStyle
import pysam as ps
import numpy as np
import collections
import matplotlib.pyplot as plt
from numpy.core.defchararray import array, center
import pysam as ps
import numpy as np
from collections import defaultdict
from scipy.ndimage.measurements import label, standard_deviation
from sklearn.cluster import KMeans
import sys
from scipy.signal import savgol_filter
import math
from subprocess import call
import os.path
from utils import Gene, TSS, Point
from scipy import stats
from sklearn import svm


dic = {
    'TSSs_l':'./data/gene/low_expressed.bed',
    'location':'./data/gene/GRCh37.gene.bed',
    'bam':'./data/051.bam',
    'test_bam':'./data/051_2.bam',
    'test_bam2':'./data/051_3.bam',
    'TSS_HK':'./data/gene/HK.bed',
    'TSS_silent':'./data/gene/silent_gene_TSS.bed'
    }

chr_to_id = {
    'chr1':'1','chr2':'2','chr3':'3','chr4':'4','chr5':'5','chr6':'6','chr7':'7','chr8':'8','chr9':'9','chr10':'10','chr11':'11','chr12':'12','chr13':'13','chr14':'14','chr15':'15','chr16':'16','chr17':'17','chr18':'18','chr19':'19','chr20':'20','chr21':'21','chr22':'22','chrX':'X','chrY':'Y'
}

up = 1000
down = 1000

bamfile = ps.AlignmentFile(dic['bam'],'rb')
testbam = ps.AlignmentFile(dic['test_bam'],'rb')
testbam2 = ps.AlignmentFile(dic['test_bam2'],'rb')

TSS_low = []
with open(dic['TSSs_l'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == 'chr1':
            TSS_low.append(TSS(chr_to_id[ll[0]],int(ll[1])))

TSS_silent = []
with open(dic['TSS_silent'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == '1':
            TSS_silent.append(TSS(ll[0], int(ll[1])+int(1000)))

TSS_HK = []
with open(dic['TSS_HK'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == '1':
            TSS_HK.append(TSS(ll[0], int(ll[1])+int(1000)))

test_HK = []
with open(dic['TSS_HK'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == '2':
            test_HK.append(TSS(ll[0], int(ll[1])+int(1000)))
test_HK2 = []
with open(dic['TSS_HK'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == '3':
            test_HK2.append(TSS(ll[0], int(ll[1])+int(1000)))

# p = 25
# TSS_silent = TSS_silent[0:p]
# TSS_HK = TSS_HK[0:p]

long_array = np.zeros((len(TSS_HK), int(up+down)), dtype=int)
short_array = np.zeros((len(TSS_HK), int(up+down)), dtype=int)
for j, tss in enumerate(TSS_HK):
    chrom = tss.chrom
    start = tss.pos - up
    end = tss.pos + down
    
    plist = []
    for r in bamfile.fetch(chrom, start-500, end + 500):
         if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse:
            ss = max(0, r.reference_start - start)
            ee = min(r.reference_start - start + abs(r.isize), end - start)
            if r.isize <= 150:
                # print("!!!!")
                for i in range(ss, ee):
                    short_array[j][i] += 1
            if r.isize > 150:
                for i in range(ss, ee):
                    long_array[j][i] += 1
    # break
    # plt.plot([i for i in range(up+down)], short_array[j], color='b')
    # plt.show()
ref_x_minus_y = [np.mean(long_array[:,i])-np.mean(short_array[:,i]) for i in range(up+down)]
# plt.plot([i for i in range(up+down)], ref_x_minus_y,color = 'b')



res = []
lab = []
for j, tss in enumerate(TSS_HK):
    chrom = tss.chrom
    start = tss.pos - up
    end = tss.pos + down
    plist = []
    ll_array = np.zeros(int(up+down),dtype=int)
    ss_array = np.zeros(int(up+down),dtype=int)
    for r in bamfile.fetch(chrom, start-500, end + 500):
         if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse:
            ss = max(0, r.reference_start - start)
            ee = min(r.reference_start - start + abs(r.isize), end - start)
            if r.isize <= 150:
                for i in range(ss, ee):
                    ss_array[i] += 1
            if r.isize > 150:
                for i in range(ss, ee):
                    ll_array[i] += 1
    # rr = []
    # for i in range(1000-150, 1000+150):
    #     mi = ll_array[i] - ss_array[i]
    #     # rr.append((mi - ref_x_minus_y[i]) ** 2)
    #     rr.append(mi)
    # res.append(rr)
    rr = 0
    for i in range(1000-150, 1000+150):
        mi = ll_array[i] - ss_array[i]
        rr += mi
    res.append([rr])
    
    lab.append(1)

res2 = []
lab2 = []
for j, tss in enumerate(TSS_silent+TSS_low):
    chrom = tss.chrom
    start = tss.pos - up
    end = tss.pos + down
    plist = []
    ll_array = np.zeros(int(up+down),dtype=int)
    ss_array = np.zeros(int(up+down),dtype=int)
    for r in bamfile.fetch(chrom, start-500, end + 500):
         if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse:
            ss = max(0, r.reference_start - start)
            ee = min(r.reference_start - start + abs(r.isize), end - start)
            if r.isize <= 150:
                for i in range(ss, ee):
                    ss_array[i] += 1
            if r.isize > 150:
                for i in range(ss, ee):
                    ll_array[i] += 1
    # rr = []
    # for i in range(1000-150, 1000+150):
    #     mi = ll_array[i] - ss_array[i]
    #     # rr.append((mi - ref_x_minus_y[i]) ** 2)
    #     rr.append(mi)
    # res2.append(rr)
    rr = 0
    for i in range(1000-150, 1000+150):
        mi = ll_array[i] - ss_array[i]
        rr += mi
    res.append([rr])
    lab2.append(0)

test_res = []
for j, tss in enumerate(test_HK):
    chrom = tss.chrom
    start = tss.pos - up
    end = tss.pos + down
    plist = []
    ll_array = np.zeros(int(up+down),dtype=int)
    ss_array = np.zeros(int(up+down),dtype=int)
    for r in testbam.fetch(chrom, start-500, end + 500):
         if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse:
            ss = max(0, r.reference_start - start)
            ee = min(r.reference_start - start + abs(r.isize), end - start)
            if r.isize <= 150:
                for i in range(ss, ee):
                    ss_array[i] += 1
            if r.isize > 150:
                for i in range(ss, ee):
                    ll_array[i] += 1
    # rr = []
    # for i in range(1000-150, 1000+150):
    #     mi = ll_array[i] - ss_array[i]
    #     # rr.append((mi - ref_x_minus_y[i]) ** 2)
    #     rr.append(mi)
    # test_res.append(rr)
    rr = 0
    for i in range(1000-150, 1000+150):
        mi = ll_array[i] - ss_array[i]
        rr += mi
    test_res.append([rr])

for j, tss in enumerate(test_HK2):
    chrom = tss.chrom
    start = tss.pos - up
    end = tss.pos + down
    plist = []
    ll_array = np.zeros(int(up+down),dtype=int)
    ss_array = np.zeros(int(up+down),dtype=int)
    for r in testbam2.fetch(chrom, start-500, end + 500):
         if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse:
            ss = max(0, r.reference_start - start)
            ee = min(r.reference_start - start + abs(r.isize), end - start)
            if r.isize <= 150:
                for i in range(ss, ee):
                    ss_array[i] += 1
            if r.isize > 150:
                for i in range(ss, ee):
                    ll_array[i] += 1
    # rr = []
    # for i in range(1000-150, 1000+150):
    #     mi = ll_array[i] - ss_array[i]
    #     # rr.append((mi - ref_x_minus_y[i]) ** 2)
    #     rr.append(mi)
    # test_res.append(rr)
    rr = 0
    for i in range(1000-150, 1000+150):
        mi = ll_array[i] - ss_array[i]
        rr += mi
    test_res.append([rr])

model = svm.SVC(kernel='linear', C=1, gamma=1)
model.fit(res+res2,lab+lab2)
pp = model.predict(test_res)
# print(pp)
ddd = {0:0,1:0}
for p in pp:
    ddd[p] += 1
print(ddd[0],ddd[1],ddd[1]/len(pp))



# plt.show()


