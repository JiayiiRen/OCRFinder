from scipy.stats import kstest
import numpy as np
import math
from matplotlib import pyplot as plt
from scipy.stats.morestats import anderson

mu = 20
sig = 3
x = np.linspace(mu-6*sig,mu+6*sig,100)
y = []
for i in x:
    tt = math.exp(-(i-mu)**2/(2*sig**2)) / (math.sqrt(2*math.pi)*sig) 
    y.append(tt)
# plt.plot(x,y)
# plt.show()
from scipy.stats import kstest, shapiro, anderson, normaltest
tt = kstest(y,'norm')
print(tt)