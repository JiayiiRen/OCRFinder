import sys

# print(len(sys.argv))
seed = sys.argv[0]
n_round = sys.argv[1]
pattern = sys.argv[2]
print(seed, n_round, pattern)
