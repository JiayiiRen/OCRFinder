import pysam as ps
import numpy as np
import collections
import matplotlib.pyplot as plt
from numpy.core.defchararray import array, center
import pysam as ps
import numpy as np
from collections import defaultdict
from scipy.ndimage.measurements import label
from sklearn.cluster import KMeans
import sys
from scipy.signal import savgol_filter
import math
from subprocess import call
import os.path
from utils import Gene, TSS, Point

dic = {
    'TSSs_l':'./data/gene/low_expressed.bed',
    'location':'./data/gene/GRCh37.gene.bed',
    'bam':'./data/051.bam',
    'TSS_HK':'./data/gene/HK.bed',
    'TSS_silent':'./data/gene/silent_gene_TSS.bed',
    'Lung':'./excel/Lung.bed',
    'Tcell':'./excel/Tcell.bed',
    'Liver':'./excel/Liver.bed',
    'Placenta':'./excel/Placenta.bed'
    }

chr_to_id = {
    'chr1':'1','chr2':'2','chr3':'3','chr4':'4','chr5':'5','chr6':'6','chr7':'7','chr8':'8','chr9':'9','chr10':'10','chr11':'11','chr12':'12','chr13':'13','chr14':'14','chr15':'15','chr16':'16','chr17':'17','chr18':'18','chr19':'19','chr20':'20','chr21':'21','chr22':'22','chrX':'X','chrY':'Y'
}


bamfile = ps.AlignmentFile(dic['bam'],'rb')

up = 1000
down = 1000

TSS_silent = []
with open(dic['TSS_silent'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == '1':
            TSS_silent.append(TSS(ll[0], int(ll[1])+int(1000)))

TSS_HK = []
with open(dic['TSS_HK'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == '1':
            TSS_HK.append(TSS(ll[0], int(ll[1])+int(1000)))

TSSs_l = []
with open(dic['Liver'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == '1':
            TSSs_l.append(TSS(ll[0],int(ll[1])))



up_array = np.zeros(up+down, dtype= int)
down_array = np.zeros(up+down, dtype= int)
# count_up_array = np.zeros(up+down, dtype= int)
for tss in TSSs_l:
    chrom = tss.chrom
    start = tss.pos - up
    end = tss.pos + down
    win_fraction = []
    plist = []
    for r in bamfile.fetch(chrom, start, end):
         if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse and r.mapq > 30:
            ss = r.reference_start - start
            ee = ss + abs(r.isize)
            if ss > 0:
                up_array[ss] += 1
            if ee < end-start:
                down_array[ee] += 1
x1 = [-1*i for i in range(401)]
x2 = [i for i in range(1,401)]
xx = sorted(x1+x2)
# print(len(xx),len(up_array[600:1400]))
plt.plot(xx, savgol_filter(up_array[600:1401],51,1), color='r')
plt.plot(xx, savgol_filter(down_array[600:1401],51,1), color = 'b')
plt.show()
