import pysam as ps
import numpy as np
import collections
import matplotlib.pyplot as plt
from numpy.core.defchararray import array, center
import pysam as ps
import numpy as np
from collections import defaultdict
from scipy.ndimage.measurements import label
from sklearn.cluster import KMeans
import sys
from scipy.signal import savgol_filter
import math
from subprocess import call
import os.path
from utils import Gene, TSS, Point

dic = {
    'TSSs_l':'./data/gene/low_expressed.bed',
    'location':'./data/gene/GRCh37.gene.bed',
    'bam':'./data/051.bam',
    'TSS_HK':'./data/gene/HK.bed',
    'TSS_silent':'./data/gene/silent_gene_TSS.bed',
    'Lung':'./excel/Lung.bed',
    'Tcell':'./excel/Tcell.bed',
    'Liver':'./excel/Liver.bed'
    }

chr_to_id = {
    'chr1':'1','chr2':'2','chr3':'3','chr4':'4','chr5':'5','chr6':'6','chr7':'7','chr8':'8','chr9':'9','chr10':'10','chr11':'11','chr12':'12','chr13':'13','chr14':'14','chr15':'15','chr16':'16','chr17':'17','chr18':'18','chr19':'19','chr20':'20','chr21':'21','chr22':'22','chrX':'X','chrY':'Y'
}


bamfile = ps.AlignmentFile(dic['bam'],'rb')

up = 1000
down = 1000

TSS_silent = []
with open(dic['TSS_silent'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == '1':
            TSS_silent.append(TSS(ll[0], int(ll[1])+int(1000)))

TSS_HK = []
with open(dic['TSS_HK'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == '1':
            TSS_HK.append(TSS(ll[0], int(ll[1])+int(1000)))
TSSs_l = []
with open(dic['Tcell'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        # if ll[0] in ['chr1']:
        #     TSSs_l.append(TSS(chr_to_id[ll[0]],int(ll[1])))
        if ll[0] in ['1']:
            TSSs_l.append(TSS(ll[0],int(ll[1])))

abs_array = np.zeros(up+down, dtype= float)
count = 0
for tss in TSS_HK:
    count += 1
    chrom = tss.chrom
    start = tss.pos - up
    end = tss.pos + down
    win_fraction = []
    plist = []
    up_array = np.zeros(up+down, dtype= int)
    down_array = np.zeros(up+down, dtype= int)
    for r in bamfile.fetch(chrom, start, end):
         if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse and r.mapq > 30:
            ss = r.reference_start - start
            ee = ss + abs(r.isize)
            if ss > 0:
                up_array[ss] += 1
            if ee < end-start:
                down_array[ee] += 1
    for i in range(len(up_array)):
        if up_array[i] - down_array[i] != 0:
            abs_array[i] += abs(up_array[i] - down_array[i])
    # if count > 5:
    #     break
abs_array = savgol_filter(abs_array,51,1)
xx = [i for i in range(len(up_array))]
plt.plot(xx, abs_array, color='r')


TSSs_l = TSSs_l[:len(TSS_HK)]
abs_array = np.zeros(up+down, dtype= float)
count = 0
for tss in TSSs_l:
    count += 1
    chrom = tss.chrom
    start = tss.pos - up
    end = tss.pos + down
    win_fraction = []
    plist = []
    up_array = np.zeros(up+down, dtype= int)
    down_array = np.zeros(up+down, dtype= int)
    for r in bamfile.fetch(chrom, start, end):
         if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse and r.mapq > 30:
            ss = r.reference_start - start
            ee = ss + abs(r.isize)
            if ss > 0:
                up_array[ss] += 1
            if ee < end-start:
                down_array[ee] += 1
    for i in range(len(up_array)):
        if up_array[i] - down_array[i] != 0:
            abs_array[i] += abs(up_array[i] - down_array[i])
    # if count > 5:
    #     break
abs_array = savgol_filter(abs_array,51,1)
xx = [i for i in range(len(up_array))]
plt.plot(xx, abs_array, color='b')

plt.show()
