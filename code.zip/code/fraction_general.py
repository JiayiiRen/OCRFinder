import pysam as ps
import numpy as np
import collections
import matplotlib.pyplot as plt
from numpy.core.defchararray import array, center, count
import pysam as ps
import numpy as np
from collections import defaultdict
from scipy.ndimage.measurements import label
from sklearn.cluster import KMeans
import sys
from scipy.signal import savgol_filter
import math
from subprocess import call
import os.path
from utils import Gene, TSS, Point

dic = {
    'TSSs_l':'./data/gene/low_expressed.bed',
    'location':'./data/gene/GRCh37.gene.bed',
    'bam':'./data/050.bam',
    'TSS_HK':'./data/gene/HK.bed',
    'TSS_silent':'./data/gene/silent_gene_TSS.bed',
    'Lung':'./excel/Lung.bed',
    'Tcell':'./excel/Tcell.bed',
    'Liver':'./excel/Liver.bed'
    }

chr_to_id = {
    'chr1':'1','chr2':'2','chr3':'3','chr4':'4','chr5':'5','chr6':'6','chr7':'7','chr8':'8','chr9':'9','chr10':'10','chr11':'11','chr12':'12','chr13':'13','chr14':'14','chr15':'15','chr16':'16','chr17':'17','chr18':'18','chr19':'19','chr20':'20','chr21':'21','chr22':'22','chrX':'X','chrY':'Y'
}


bamfile = ps.AlignmentFile(dic['bam'],'rb')

up = 1000
down = 1000

TSSs_l = []
with open(dic['Tcell'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == '1':
            TSSs_l.append(TSS(ll[0],int(ll[1])))
# TSSs_l = []
# with open(dic['TSSs_l'],'r') as f:
#     for line in f:
#         ll = line.strip().split('\t')
#         if ll[0] == 'chr1':
#             TSSs_l.append(TSS(chr_to_id[ll[0]],int(ll[1])))
TSS_silent = []
with open(dic['TSS_silent'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == '1':
            TSS_silent.append(TSS(ll[0], int(ll[1])+int(1000)))

TSS_HK = []
with open(dic['TSS_HK'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == '1':
            TSS_HK.append(TSS(ll[0], int(ll[1])+int(1000)))



win = 200
win_fraction_l = np.zeros(int(2*(up+down)/win-1), dtype=float)
win_min_l = np.zeros(int(2*(up+down)/win-1), dtype=float)
for i in range(len(win_min_l)):
    win_min_l[i] = 1
win_max_l = np.zeros(int(2*(up+down)/win-1), dtype=float)
count_array = np.zeros(int(2*(up+down)/win-1),dtype=int)
# TSSs_l = TSS_silent
for tss in TSS_silent:
    chrom = tss.chrom
    start = tss.pos - up
    end = tss.pos + down
    
    plist = []
    for r in bamfile.fetch(chrom, start, end):
         if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse and r.mapq > 30:
            ss = r.reference_start
            ee = abs(r.isize)
            plist.append(Point(ss, ee))
    plist = sorted(plist, key= lambda a: a.x)
    k = start
    num_win = []
    i = 0
    while True:
        # print(i)
        ss = k
        ee = k + win
        if ee > end:
            break
        k = k + win / 2
        _set = [p for p in plist if ss <= p.x <= ee ] # ss <= p.x <= ee and p.x + p.y <= ee
        # if len(_set) == 0:
        #     continue
        s1 = [p for p in _set if p.y <= 140]
        s2 = [p for p in _set if p.y > 140]
        if len(s1) + len(s2) != 0:
            fraction = float(len(s1)/(len(s1)+len(s2)))
            win_fraction_l[i] += fraction
            count_array[i] += 1
            if 1 > fraction > win_max_l[i]:
                win_max_l[i] = fraction
            if 0 < fraction < win_min_l[i]:
                win_min_l[i] = fraction
        i += 1

plt.plot([i for i in range(len(win_fraction_l))], [win_fraction_l[i] / count_array[i] for i in range(len(win_fraction_l))], color = 'b')
# plt.plot([i for i in range(len(win_min_l))], win_min_l,color = 'g')
# plt.plot([i for i in range(len(win_max_l))], win_max_l,color = 'g')

win_fraction_HK = np.zeros(int(2*(up+down)/win-1), dtype=float)
win_min_HK = np.zeros(int(2*(up+down)/win-1), dtype=float)
for i in range(len(win_min_HK)):
    win_min_HK[i] = 1
win_max_HK = np.zeros(int(2*(up+down)/win-1), dtype=float)

count_array = np.zeros(int(2*(up+down)/win-1),dtype=int)
# TSS_HK = TSSs_l
for tss in TSS_HK:
    chrom = tss.chrom
    start = tss.pos - up
    end = tss.pos + down
    
    plist = []
    for r in bamfile.fetch(chrom, start, end):
         if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse and r.mapq > 30:
            ss = r.reference_start
            ee = abs(r.isize)
            plist.append(Point(ss, ee))
    plist = sorted(plist, key= lambda a: a.x)
    k = start
    num_win = []
    i = 0
    while True:
        ss = k
        ee = k + win
        if ee > end:
            break
        k = k + win / 2
        _set = [p for p in plist if ss <= p.x <= ee ] # ss <= p.x <= ee and p.x + p.y <= ee
        s1 = [p for p in _set if p.y <= 140]
        s2 = [p for p in _set if p.y > 140]
        if len(s1) + len(s2) != 0:
            fraction = float(len(s1)/(len(s1)+len(s2)))
            win_fraction_HK[i] += fraction
            count_array[i] += 1
            if  0 < fraction < win_min_HK[i]:
                win_min_HK[i] = fraction
            if  1 > fraction > win_max_HK[i]:
                win_max_HK[i] = fraction 
        i += 1
plt.plot([i for i in range(len(win_fraction_HK))], [win_fraction_HK[i] / count_array[i] for i in range(len(win_fraction_HK))], color = 'r')
# plt.plot([i for i in range(len(win_min_HK))], win_min_HK,color = 'y')
# plt.plot([i for i in range(len(win_max_HK))], win_max_HK,color = 'y')
plt.show()
