from collections import defaultdict
import numpy as np
from numpy.core.defchararray import array
from sklearn.cluster import KMeans

class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y


def cluster(plist):
    y1 = plist[0].y
    y2 = plist[1].y
    i = 0
    s1 = [plist[0]]
    s2 = [plist[1]]
    while i < 1000:
        
        for p in plist:
            if p in s1 or p in s2:
                continue
            if abs(p.y - y1) < abs(p.y - y2):
                s1.append(p)
            else:
                s2.append(p)
            
        y1 = np.mean(np.array([p.y for p in s1]))
        y2 = np.mean(np.array([p.y for p in s2]))
        i = i + 1
        if i < 1000:
            s1 = []
            s2 = []
    return s1, s2


# x = [893648, 893648, 893667, 893754, 893754, 893754, 893757, 893765, 893776, 893777, 893779, 893779, 893779, 893784, 893790, 893790, 893798, 893799, 893800, 893802, 893804, 893807, 893820, 893826]
# y = [157, 157, 136, 175, 105, 105, 116, 162, 136, 165, 100, 100, 147, 165, 169, 152, 144, 171, 158, 138, 136, 94, 75, 125]
# plist = [Point(x[i],y[i]) for i in range(len(x))]
# s1, s2 = cluster(plist)
# print

# 
# a = np.zeros((2,4),dtype= float)
# print(len(a),a[:,0])
# import matplotlib.pyplot as plt 
# a = [2,5,8,3,2]
# x = [1,2,3,4,5]
# a = sorted(a)
# plt.bar(x,a)
# plt.show()

import matplotlib.pyplot as plt
import numpy as np
from scipy import stats

# from matplotlib import style
# style.use('ggplot')
# x = np.linspace(0,1,100)
# pdf = stats.beta(50,50).pdf(x)

# plt.plot(x, pdf)
# plt.show()
# from sklearn import svm

# x_train = [[7],[8],[9],[7],[8],[9],[1],[2],[3],[1],[2],[3]]
# y_train = [1,1,1,1,1,1,0,0,0,0,0,0]
# x_test = [[6],[-1],[2],[10]]
# model = svm.SVC(kernel='linear', C=1, gamma=1)
# model.fit(x_train,y_train)
# print(model.score(x_train,y_train))
# pp = model.predict(x_test)
# print(pp)

# aa = np.zeros((3,5),dtype=int)
# # print(aa[:,0])
# print(aa[1,2])
# a = np.array([1,2,3])
# b = np.array([4,5,6])
# print((a+b))

import numpy as np
from scipy.fftpack import fft,ifft
import matplotlib.pyplot as plt
import seaborn
 
 
#采样点选择1400个，因为设置的信号频率分量最高为600赫兹，根据采样定理知采样频率要大于信号频率2倍，所以这里设置采样频率为1400赫兹（即一秒内有1400个采样点，一样意思的）
x=np.linspace(0,1,4000)  

#设置需要采样的信号，频率分量有180，390和600
y=7*np.sin(2*np.pi*20*x)

x2 = np.linspace(0,1,200)
y2 = -10*np.sin(np.pi*x2)

for i in range(len(y2)):
    y[i+1900] = y2[i]#0.15*y[i+1900] + 0.85*y2[i]


# plt.subplot(211)
plt.plot([i for i in range(len(y))],y) 
# plt.title('Original wave')
# plt.subplot(212)
# plt.plot(x2,y2)
plt.show()

T = 200
k = 0
while True:
    ss = k
    ee = k + 3*T
    k = k + T
    yy = fft(y[ss:ee])
    yreal = yy.real
    yimag = yy.imag
    yf = abs(yy)
    yf1 = yf/len(y[ss:ee])
    yf2 = yf1[:int(len(yf1)/2)]

    xf = np.arange(len(y[ss:ee]))
    xf1 = xf
    xf2 = xf1[:int(len(xf1)/2)]
    plt.subplot(211)
    plt.title(str(ss)+'-'+str(ee))
    plt.plot([i for i in range(len(y[ss:ee]))],y[ss:ee])
    plt.subplot(212)
    
    plt.bar(xf2[:70], yf2[:70])

    plt.show()
    if ee >= 4000:
        break



# yy=fft(y)      #快速傅里叶变换
# yreal = yy.real    # 获取实数部分
# yimag = yy.imag    # 获取虚数部分
 
# yf=abs(fft(y))    # 取绝对值
# yf1=abs(fft(y))/len(x)   #归一化处理
# yf2 = yf1[range(int(len(x)/2))] #由于对称性，只取一半区间
 
# xf = np.arange(len(y))  # 频率
# xf1 = xf
# xf2 = xf[range(int(len(x)/2))] #取一半区间
 
 

 

# plt.plot(xf,yf,'r')
# plt.title('FFT of Mixed wave(two sides frequency range)',fontsize=7,color='#7A378B') #注意这里的颜色可以查询颜色代码表
 
# plt.subplot(223)
# plt.plot(xf1,yf1,'g')
# plt.title('FFT of Mixed wave(normalization)',fontsize=9,color='r')
 
# plt.subplot(224)
# plt.plot(xf2,yf2,'b')
# plt.title('FFT of Mixed wave)',fontsize=10,color='#F08080')
 
 
plt.show()