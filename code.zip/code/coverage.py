import pysam as ps
import numpy as np
import collections
import matplotlib.pyplot as plt
from numpy.core.defchararray import array, center
import pysam as ps
import numpy as np
from collections import defaultdict
from scipy.ndimage.measurements import label
from sklearn.cluster import KMeans
import sys
from scipy.signal import savgol_filter
import math
from subprocess import call
import os.path


dic = {
    'TSSs_l':'./data/gene/low_expressed.bed',
    'location':'./data/gene/GRCh37.gene.bed',
    'bam':'./data/051.bam',
    'TSS_HK':'./data/gene/HK.bed',
    'Lung':'./excel/Lung.bed',
    'Tcell':'./excel/Tcell.bed',
    'Liver':'./excel/Liver.bed'
    }

chr_to_id = {
    'chr1':'1','chr2':'2','chr3':'3','chr4':'4','chr5':'5','chr6':'6','chr7':'7','chr8':'8','chr9':'9','chr10':'10','chr11':'11','chr12':'12','chr13':'13','chr14':'14','chr15':'15','chr16':'16','chr17':'17','chr18':'18','chr19':'19','chr20':'20','chr21':'21','chr22':'22','chrX':'X','chrY':'Y'
}

class Gene:
    def __init__(self, chrom, start, end, strand, name):
        self.chrom = chrom
        self.start = start
        self.end = end
        self.strand = strand
        self.name = name

class TSS:
    def __init__(self, chrom, pos):
        self.chrom = chrom
        self.pos = pos

    def __str__(self):
        return str(self.chrom) + str(self.pos)

up = 5000
down = 5000

TSSs_l = []
# with open(dic['TSSs_l'],'r') as f:
#     for line in f:
#         ll = line.strip().split('\t')
#         if ll[0] == 'chr1':
#             TSSs_l.append(TSS(chr_to_id[ll[0]],int(ll[1])))
'''
#tissue_specific
'''
TSSs_l = []
with open(dic['Liver'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == '1':
            TSSs_l.append(TSS(ll[0],int(ll[1])))

TSS_HK = []
with open(dic['TSS_HK'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == '1':
            TSS_HK.append(TSS(ll[0], int(ll[1])+int(1000)))



from tqdm import tqdm

'''
#low expression region
'''
lcount = 0
center_coverage = np.zeros(up+down+1, dtype=float)
for i in tqdm(range(len(TSSs_l))):
    tss = TSSs_l[i]
    coverage_list = []
    start1 = tss.pos - 3000
    end1 = tss.pos - 1000
    TMP_COVERAGE_BED = open('./data/gene/'+tss.chrom+str(tss.pos)+'_up.bed','w')
    # print("samtools","depth","-a","-r",tss.chrom+":"+str(start1)+"-"+str(end1),dic['bam'])
    call(["samtools","depth","-a","-r",tss.chrom+":"+str(start1)+"-"+str(end1),dic['bam']], stdout=TMP_COVERAGE_BED)
    # cmd = "samtools depth -a -r {}:{}-{} {} > {}".format(tss.chrom,start1,end1, dic['bam'], './data/gene/'+tss.chrom+str(tss.pos)+'_up')
    # call(cmd,shell=True)
    TMP_COVERAGE_BED.close()
    TMP_COVERAGE_BED_OUTPUT = open('./data/gene/'+tss.chrom+str(tss.pos)+'_up.bed','r')
    content = TMP_COVERAGE_BED_OUTPUT.readlines()
    for line in content:
        coverage_list.append(int(line.split()[2]))
    TMP_COVERAGE_BED_OUTPUT.close()
    # call(["rm",'./data/gene/'+tss.chrom+str(tss.pos)+'_up'])
    
    start2 = tss.pos + 1000
    end2 = tss.pos + 3000
    TMP_COVERAGE_BED = open('./data/gene/'+tss.chrom+str(tss.pos)+'_dowm.bed','w')
    call(["samtools","depth","-a","-r",tss.chrom+":"+str(start2)+"-"+str(end2),dic['bam']], stdout=TMP_COVERAGE_BED)
    TMP_COVERAGE_BED.close()
    TMP_COVERAGE_BED_OUTPUT = open('./data/gene/'+tss.chrom+str(tss.pos)+'_dowm.bed','r')
    content = TMP_COVERAGE_BED_OUTPUT.readlines()
    for line in content:
        coverage_list.append(int(line.split()[2]))
    TMP_COVERAGE_BED_OUTPUT.close()
    call(["rm",'./data/gene/'+tss.chrom+str(tss.pos)+'_dowm.bed'])
    call(["rm",'./data/gene/'+tss.chrom+str(tss.pos)+'_up.bed'])
    control_coverage = np.mean(coverage_list)
    if control_coverage == 0:
        continue
    
    start = tss.pos - up
    end = tss.pos + down
    TMP_COVERAGE_BED = open('./data/gene/'+tss.chrom+str(tss.pos)+'_center.bed','w')
    call(["samtools","depth","-a","-r",tss.chrom+":"+str(start)+"-"+str(end),dic['bam']], stdout=TMP_COVERAGE_BED)
    TMP_COVERAGE_BED.close()
    TMP_COVERAGE_BED_OUTPUT = open('./data/gene/'+tss.chrom+str(tss.pos)+'_center.bed','r')
    content = TMP_COVERAGE_BED_OUTPUT.readlines()
    for i, line in enumerate(content):
        center_coverage[i] += float(int(line.split()[2]))#/control_coverage)
    TMP_COVERAGE_BED_OUTPUT.close()
    call(["rm",'./data/gene/'+tss.chrom+str(tss.pos)+'_center.bed'])
    
    lcount += 1
x = [i for i in range(len(center_coverage))]
plt.plot(x,[float(i / lcount) for i in center_coverage], color = 'b')

# sys.exit()
# '''
#HK
# count  = 0
# center_coverage = np.zeros(2001,dtype=float)
# # print(center_coverage)
# for tss in TSS_HK:
#     coverage_list = []
#     start1 = tss.pos - 3000
#     end1 = tss.pos - 1000
#     TMP_COVERAGE_BED = open('./data/gene/'+tss.chrom+str(tss.pos)+'_up.bed','w')
#     # print("samtools","depth","-a","-r",tss.chrom+":"+str(start1)+"-"+str(end1),dic['bam'])
#     call(["samtools","depth","-a","-r",tss.chrom+":"+str(start1)+"-"+str(end1),dic['bam']], stdout=TMP_COVERAGE_BED)
#     # cmd = "samtools depth -a -r {}:{}-{} {} > {}".format(tss.chrom,start1,end1, dic['bam'], './data/gene/'+tss.chrom+str(tss.pos)+'_up')
#     # call(cmd,shell=True)
#     TMP_COVERAGE_BED.close()
#     TMP_COVERAGE_BED_OUTPUT = open('./data/gene/'+tss.chrom+str(tss.pos)+'_up.bed','r')
#     content = TMP_COVERAGE_BED_OUTPUT.readlines()
#     for line in content:
#         coverage_list.append(int(line.split()[2]))
#     TMP_COVERAGE_BED_OUTPUT.close()
#     # call(["rm",'./data/gene/'+tss.chrom+str(tss.pos)+'_up'])
    
#     start2 = tss.pos + 1000
#     end2 = tss.pos + 3000
#     TMP_COVERAGE_BED = open('./data/gene/'+tss.chrom+str(tss.pos)+'_dowm.bed','w')
#     call(["samtools","depth","-a","-r",tss.chrom+":"+str(start2)+"-"+str(end2),dic['bam']], stdout=TMP_COVERAGE_BED)
#     TMP_COVERAGE_BED.close()
#     TMP_COVERAGE_BED_OUTPUT = open('./data/gene/'+tss.chrom+str(tss.pos)+'_dowm.bed','r')
#     content = TMP_COVERAGE_BED_OUTPUT.readlines()
#     for line in content:
#         coverage_list.append(int(line.split()[2]))
#     TMP_COVERAGE_BED_OUTPUT.close()
#     call(["rm",'./data/gene/'+tss.chrom+str(tss.pos)+'_dowm.bed'])
#     call(["rm",'./data/gene/'+tss.chrom+str(tss.pos)+'_up.bed'])
#     control_coverage = np.mean(coverage_list)
#     if control_coverage == 0:
#         continue
    
#     start = tss.pos - 1000
#     end = tss.pos + 1000
#     TMP_COVERAGE_BED = open('./data/gene/'+tss.chrom+str(tss.pos)+'_center.bed','w')
#     call(["samtools","depth","-a","-r",tss.chrom+":"+str(start)+"-"+str(end),dic['bam']], stdout=TMP_COVERAGE_BED)
#     TMP_COVERAGE_BED.close()
#     TMP_COVERAGE_BED_OUTPUT = open('./data/gene/'+tss.chrom+str(tss.pos)+'_center.bed','r')
#     content = TMP_COVERAGE_BED_OUTPUT.readlines()
#     for i, line in enumerate(content):
#         center_coverage[i] += float(int(line.split()[2]))# / control_coverage)
#     TMP_COVERAGE_BED_OUTPUT.close()
#     call(["rm",'./data/gene/'+tss.chrom+str(tss.pos)+'_center.bed'])
#     x = [i for i in range(len(center_coverage))]
    
#     count += 1
#     # if count > 5:
#     #     break
# # '''
# plt.plot(x,[float(i / count) for i in center_coverage], color = 'r')



plt.show()