# from fraction_general import TSSs_l
import pysam as ps
import numpy as np
import collections
import matplotlib.pyplot as plt
from numpy.core.defchararray import array, center
import pysam as ps
import numpy as np
from collections import defaultdict
from scipy.ndimage.measurements import label
from sklearn.cluster import KMeans
import sys
from scipy.signal import savgol_filter
import math
from subprocess import call
import os.path
from utils import Gene, TSS, Point

dic = {
    # 'TSSs_l':'./data/gene/low_expressed.bed',
    # 'location':'./data/gene/GRCh37.gene.bed',
    'bam':'./data/051.bam',
    'HK':'./data/gene/HK_gene_location.bed',
    'silent':'./data/gene/silent_gene_location.bed'
    }

chr_to_id = {
    'chr1':'1','chr2':'2','chr3':'3','chr4':'4','chr5':'5','chr6':'6','chr7':'7','chr8':'8','chr9':'9','chr10':'10','chr11':'11','chr12':'12','chr13':'13','chr14':'14','chr15':'15','chr16':'16','chr17':'17','chr18':'18','chr19':'19','chr20':'20','chr21':'21','chr22':'22','chrX':'X','chrY':'Y'
}

bamfile = ps.AlignmentFile(dic['bam'],'rb')


gene_HK = []
with open(dic['HK'],'r') as f:
    for line in f:
        ll = line.strip().split('\t')
        if ll[0] == '1' and ll[3] == '-':
            gene_HK.append(Gene(ll[0], int(ll[1]), int(ll[2]), ll[3], ll[4]))

win = 200
count = 0
# print(len(gene_HK))
for j, gg in enumerate(gene_HK):
    chrom = gg.chrom 
    start = gg.start -1000
    end = gg.end + 1000
    win_fraction = []

    plist = []
    for r in bamfile.fetch(chrom, start, end):
         if (not r.is_reverse) and (not r.is_unmapped) and (not r.mate_is_unmapped) and r.mate_is_reverse and r.mapq > 30:
            ss = r.reference_start
            ee = abs(r.isize)
            plist.append(Point(ss, ee))
    plist = sorted(plist, key= lambda a: a.x)
    k = start
    num_win = []
    i = 0
    while True:
        # print(i)
        ss = k
        ee = k + win
        if ee > end:
            break
        k = k + win / 2
        _set = [p for p in plist if ss <= p.x <= ee ] # ss <= p.x <= ee and p.x + p.y <= ee
        # if len(_set) == 0:
        #     continue
        s1 = [p for p in _set if p.y <= 140]
        s2 = [p for p in _set if p.y > 140]
        if len(s1) + len(s2) != 0:
            fraction = float(len(s1)/(len(s1)+len(s2)))
            win_fraction.append(fraction)
    if len(win_fraction) == 0:
        continue
    plt.plot([i for i in range(len(win_fraction))], [i for i in win_fraction],color = 'b')
    plt.show()

    count += 1
    if count > 5:
        break